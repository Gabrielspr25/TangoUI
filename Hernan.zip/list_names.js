const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const items = await prisma.inventario.findMany({
    where: { tiendaid: 2, activado: false },
    select: { equipo: { select: { nombre: true } } },
    distinct: ['equipoid']
  });
  const names = items.map(i => i.equipo?.nombre).filter(n => n).sort();
  console.log("Distinct Equipment Names:");
  names.forEach(n => console.log(n));
}
main();
