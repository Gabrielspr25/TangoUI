import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    try {
        const items = await prisma.inventario.findMany({
            where: {
                tiendaid: BigInt(2),
                activado: false,
                generico: false
            },
            take: 300,
            include: { equipo: true }
        });

        // Extract names
        const names = Array.from(new Set(items.map(i => i.equipo?.nombre).filter(n => n))).sort();

        console.log(`Found ${items.length} items.`);
        console.log(`Found ${names.length} distinct names.`);
        console.log("--- NAMES START ---");
        names.forEach(n => console.log(n));
        console.log("--- NAMES END ---");

    } catch (e) {
        console.error(e);
    } finally {
        await prisma.$disconnect();
    }
}
main();
