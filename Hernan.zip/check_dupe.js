const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const imei = '353410932081502';
  try {
    const items = await prisma.inventario.findMany({
      where: { emai: imei },
      select: { inventarioid: true, activado: true, generico: true, tiendaid: true, fechacompra: true }
    });
    console.log("Items found for IMEI " + imei + ": " + items.length);
    console.log(JSON.stringify(items, (k, v) => typeof v === 'bigint' ? v.toString() : v, 2));
  } catch (e) {
    console.error(e);
  } finally {
    await prisma.$disconnect();
  }
}
main();
