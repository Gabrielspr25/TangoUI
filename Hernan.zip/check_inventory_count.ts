import prisma from './src/lib/prisma';

async function checkInventoryCounts() {
    try {
        // Count by store and activado status
        const stores = await prisma.tienda.findMany();

        for (const store of stores) {
            console.log(`\n=== ${store.nombre} (ID: ${store.tiendaid}) ===`);

            // Total items (excluding generics)
            const total = await prisma.inventario.count({
                where: {
                    tiendaid: store.tiendaid,
                    generico: false,
                }
            });

            // Items with activado = false
            const activeFalse = await prisma.inventario.count({
                where: {
                    tiendaid: store.tiendaid,
                    activado: false,
                    generico: false,
                }
            });

            // Items with activado = true
            const activeTrue = await prisma.inventario.count({
                where: {
                    tiendaid: store.tiendaid,
                    activado: true,
                    generico: false,
                }
            });

            console.log(`Total (sin genéricos): ${total}`);
            console.log(`Activado = false: ${activeFalse}`);
            console.log(`Activado = true: ${activeTrue}`);
        }

        await prisma.$disconnect();
    } catch (error) {
        console.error('Error:', error);
        await prisma.$disconnect();
        process.exit(1);
    }
}

checkInventoryCounts();
