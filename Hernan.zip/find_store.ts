import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  try {
    const store = await prisma.tienda.findFirst({
      where: {
        nombre: {
          contains: 'Plaza Dorada',
          mode: 'insensitive'
        }
      }
    });
    // Serialize BigInt for JSON.stringify
    const serialized = JSON.stringify(store, (key, value) =>
      typeof value === 'bigint' ? value.toString() : value
    );
    console.log('Store_Found:', serialized);
  } catch (e) {
    console.error(e);
  }
}

main()
  .catch(e => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
