import prisma from './src/lib/prisma';

async function checkActiveStores() {
    try {
        const activeStores = await prisma.tienda.findMany({
            where: {
                tiendaactivo: true,
            },
            select: {
                tiendaid: true,
                nombre: true,
            },
            orderBy: {
                nombre: 'asc',
            },
        });

        console.log('=== TIENDAS ACTIVAS ===');
        for (const store of activeStores) {
            const count = await prisma.inventario.count({
                where: {
                    tiendaid: store.tiendaid,
                    activado: false,
                    generico: false,
                }
            });
            console.log(`${store.nombre} (ID: ${store.tiendaid}): ${count} items con activado=false`);
        }

        await prisma.$disconnect();
    } catch (error) {
        console.error('Error:', error);
        await prisma.$disconnect();
        process.exit(1);
    }
}

checkActiveStores();
