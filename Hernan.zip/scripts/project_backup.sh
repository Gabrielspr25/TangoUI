#!/bin/bash

# Configuration
BACKUP_ROOT=".backups/full_project"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="backup_$TIMESTAMP.tar.gz"
BACKUP_PATH="$BACKUP_ROOT/$BACKUP_NAME"

# Create backup directory
mkdir -p "$BACKUP_ROOT"

# Create tarball
# Excluding: node_modules, .next (build), .git, .backups (recursive), .DS_Store
echo "📦 Creating project backup..."
tar -czf "$BACKUP_PATH" \
    --exclude='node_modules' \
    --exclude='.next' \
    --exclude='.git' \
    --exclude='.backups' \
    --exclude='.DS_Store' \
    .

# Verify
if [ -f "$BACKUP_PATH" ]; then
    SIZE=$(du -h "$BACKUP_PATH" | cut -f1)
    echo "✅ Backup created successfully!"
    echo "   Path: $BACKUP_PATH"
    echo "   Size: $SIZE"
    
    # Cleanup: Keep only last 20 backups
    COUNT=$(ls -1 "$BACKUP_ROOT"/*.tar.gz 2>/dev/null | wc -l)
    if [ "$COUNT" -gt 20 ]; then
        echo "🧹 Cleaning up old backups (keeping last 20)..."
        ls -t "$BACKUP_ROOT"/*.tar.gz | tail -n +21 | xargs rm -f
    fi
else
    echo "❌ Backup failed!"
    exit 1
fi
