#!/bin/bash
# Automatic backup script for critical files
# Usage: ./scripts/backup.sh <file_path> [backup_name]

set -e

BACKUP_DIR=".backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
FILE_PATH="$1"
BACKUP_NAME="${2:-auto}"

if [ -z "$FILE_PATH" ]; then
    echo "Error: No file path provided"
    echo "Usage: $0 <file_path> [backup_name]"
    exit 1
fi

if [ ! -f "$FILE_PATH" ]; then
    echo "Error: File '$FILE_PATH' does not exist"
    exit 1
fi

# Create backup directory structure
FILE_DIR=$(dirname "$FILE_PATH")
BACKUP_SUBDIR="$BACKUP_DIR/$FILE_DIR"
mkdir -p "$BACKUP_SUBDIR"

# Create backup filename
BASENAME=$(basename "$FILE_PATH")
BACKUP_FILE="$BACKUP_SUBDIR/${BASENAME}.${BACKUP_NAME}.${TIMESTAMP}.bak"

# Copy file
cp "$FILE_PATH" "$BACKUP_FILE"

echo "✅ Backup created: $BACKUP_FILE"
echo "   Original: $FILE_PATH"
echo "   Size: $(du -h "$BACKUP_FILE" | cut -f1)"

# Keep only last 10 backups per file
ls -t "$BACKUP_SUBDIR/${BASENAME}."*.bak 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true

exit 0
