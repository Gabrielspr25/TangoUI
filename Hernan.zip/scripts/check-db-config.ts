
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    try {
        const clients = await prisma.bbddclientes.findMany();
        console.log("Client Configurations:");
        clients.forEach(c => {
            console.log(`ID: ${c.bbddclientesid}, Name: ${c.nombre}, IP: ${c.ip}, Port: ${c.puerto}, DB: ${c.nombrebase}`);
        });
    } catch (e) {
        console.error(e);
    } finally {
        await prisma.$disconnect();
    }
}

main();
