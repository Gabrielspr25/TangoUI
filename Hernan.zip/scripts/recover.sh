#!/bin/bash
# Recovery script to restore from backups
# Usage: ./scripts/recover.sh <file_path> [backup_timestamp]

set -e

BACKUP_DIR=".backups"
FILE_PATH="$1"
BACKUP_TIMESTAMP="$2"

if [ -z "$FILE_PATH" ]; then
    echo "Error: No file path provided"
    echo "Usage: $0 <file_path> [backup_timestamp]"
    exit 1
fi

FILE_DIR=$(dirname "$FILE_PATH")
BASENAME=$(basename "$FILE_PATH")
BACKUP_SUBDIR="$BACKUP_DIR/$FILE_DIR"

if [ ! -d "$BACKUP_SUBDIR" ]; then
    echo "Error: No backups found for '$FILE_PATH'"
    exit 1
fi

# List available backups
echo "📦 Available backups for $FILE_PATH:"
echo "----------------------------------------"
ls -lht "$BACKUP_SUBDIR/${BASENAME}."*.bak 2>/dev/null | awk '{print NR". "$9" ("$5", "$6" "$7" "$8")"}'

if [ -z "$BACKUP_TIMESTAMP" ]; then
    echo ""
    echo "To restore, run: $0 $FILE_PATH <backup_number_or_timestamp>"
    exit 0
fi

# Find backup file
if [[ "$BACKUP_TIMESTAMP" =~ ^[0-9]+$ ]]; then
    # Backup number provided
    BACKUP_FILE=$(ls -t "$BACKUP_SUBDIR/${BASENAME}."*.bak 2>/dev/null | sed -n "${BACKUP_TIMESTAMP}p")
else
    # Timestamp provided
    BACKUP_FILE=$(ls "$BACKUP_SUBDIR/${BASENAME}."*"${BACKUP_TIMESTAMP}"*.bak 2>/dev/null | head -1)
fi

if [ -z "$BACKUP_FILE" ] || [ ! -f "$BACKUP_FILE" ]; then
    echo "Error: Backup not found"
    exit 1
fi

# Create safety backup of current file if it exists
if [ -f "$FILE_PATH" ]; then
    SAFETY_BACKUP="${FILE_PATH}.before_recovery.$(date +%Y%m%d_%H%M%S).bak"
    cp "$FILE_PATH" "$SAFETY_BACKUP"
    echo "⚠️  Current file backed up to: $SAFETY_BACKUP"
fi

# Restore
cp "$BACKUP_FILE" "$FILE_PATH"
echo "✅ Restored: $FILE_PATH"
echo "   From: $BACKUP_FILE"

exit 0
