import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log("--- ACTIVADO = TRUE (Expected: In Stock) ---");
  const trueItems = await prisma.inventario.findMany({
    where: { activado: true, generico: false },
    take: 3,
    select: { inventarioid: true, activado: true, fechacompra: true, emai: true, equipo: { select: { nombre: true } } }
  });
  console.log(JSON.stringify(trueItems, null, 2));

  console.log("\n--- ACTIVADO = FALSE (Expected: Sold/Inactive) ---");
  const falseItems = await prisma.inventario.findMany({
    where: { activado: false, generico: false },
    take: 3,
    select: { inventarioid: true, activado: true, fechacompra: true, emai: true, equipo: { select: { nombre: true } } }
  });
  console.log(JSON.stringify(falseItems, null, 2));
}

main()
  .catch(e => console.error(e))
  .finally(async () => await prisma.$disconnect());
