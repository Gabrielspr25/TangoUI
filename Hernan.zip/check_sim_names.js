const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const sims = await prisma.inventario.findMany({
    where: { 
        equipo: {
            nombre: { contains: 'SIM', mode: 'insensitive' }
        },
        tiendaid: 2,
        activado: false
    },
    take: 10,
    select: { equipo: { select: { nombre: true, codigo: true } } }
  });
  console.log("Sample SIMs:", JSON.stringify(sims, null, 2));
}
main();
