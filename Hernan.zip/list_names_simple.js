const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  try {
    const items = await prisma.inventario.findMany({
        where: { tiendaid: 2, activado: false },
        take: 200,
        include: { equipo: true }
    });
    
    const names = [...new Set(items.map(i => i.equipo?.nombre).filter(n => n))].sort();
    console.log("Found " + names.length + " distinct names:");
    names.forEach(n => console.log(n));
  } catch (e) {
      console.error(e);
  } finally {
      await prisma.();
  }
}
main();
