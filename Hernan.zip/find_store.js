
const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

async function main() {
    const store = await prisma.tienda.findFirst({
        where: {
            nombre: {
                contains: 'Plaza Dorada',
                mode: 'insensitive'
            }
        }
    })

    if (store) {
        // Serialize manually to avoid BigInt issues
        const result = {
            tiendaid: store.tiendaid.toString(),
            nombre: store.nombre
        };
        console.log('Store_Found:', JSON.stringify(result));
    } else {
        console.log('Store_Found: null');
    }
}

main()
    .catch(e => {
        console.error(e)
        process.exit(1)
    })
    .finally(async () => {
        await prisma.$disconnect()
    })
