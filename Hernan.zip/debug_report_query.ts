
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    const storeId = 2; // Testing with Store 2
    console.log(`Testing Report Query for Store ${storeId}...`);

    try {
        const results = await prisma.$queryRaw`
            SELECT 
                v.ventaid, 
                v.fechaactivacion as fecha, 
                v.emai as serial, 
                v.simcard as simcard,
                v.numerocelularactivado as telefono, 
                i.inventarioid, 
                i.activado, 
                e.nombre as equipo_nombre, 
                e.codigo as equipo_codigo
            FROM venta v
            JOIN inventario i ON (v.emai = i.emai OR (v.simcard IS NOT NULL AND v.simcard != '' AND v.simcard = i.emai))
            LEFT JOIN equipo e ON i.equipoid = e.equipoid
            WHERE v.activo = true
              AND i.activado = false
              AND i.generico = false
              AND v.tiendaid = ${BigInt(storeId)}
              AND (
                -- Caso 1: NO es Simcard -> Validar por IMEI (v.emai = i.emai)
                (e.nombre NOT ILIKE '%Simcard%' AND v.emai = i.emai)
                OR
                -- Caso 2: SI es Simcard -> Validar por campo Simcard (v.simcard = i.emai)
                (e.nombre ILIKE '%Simcard%' AND v.simcard = i.emai)
              )
            ORDER BY v.fechaactivacion DESC
            LIMIT 100
        `;

        console.log("Query successful.");
        console.log(`Found ${(results as any[]).length} items.`);
        if ((results as any[]).length > 0) {
            console.log("First item:", (results as any[])[0]);
        }

    } catch (error) {
        console.error("Query FAILED:", error);
    } finally {
        await prisma.$disconnect();
    }
}

main();
