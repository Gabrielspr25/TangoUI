'use server';

import { cookies } from 'next/headers';
import prisma from '@/lib/prisma';

export async function switchConnection(clientId: string) {
    const cookieStore = await cookies();

    if (clientId === 'master') {
        cookieStore.delete('active_client');
    } else {
        // Validate that the client exists before setting cookie
        const client = await prisma.bbddclientes.findFirst({
            where: {
                bbddclientesid: BigInt(clientId),
            },
        });

        if (client) {
            cookieStore.set('active_client', clientId, {
                path: '/',
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'lax',
                maxAge: 60 * 60 * 24 * 7, // 1 week
            });
        } else {
            throw new Error('Invalid client ID');
        }
    }
}

export async function getClientList() {
    const clients = await prisma.bbddclientes.findMany({
        select: {
            bbddclientesid: true,
            nombre: true,

            // Don't expose sensitive connection details to client
        }
    });

    // Convert BigInt to string for serialization
    return clients.map(c => ({
        id: c.bbddclientesid.toString(),
        nombre: c.nombre || 'Sin Nombre'
    }));
}

export async function getConnectionInfo() {
    const cookieStore = await cookies();
    const clientId = cookieStore.get('active_client')?.value;

    if (!clientId || clientId === 'master') {
        return { name: 'Master', id: 'master' };
    }

    try {
        const clientConfig = await prisma.bbddclientes.findFirst({
            where: {
                bbddclientesid: BigInt(clientId),
            },
        });

        return {
            name: clientConfig?.nombre || 'Unknown',
            id: clientId
        };
    } catch (e) {
        return { name: 'Error', id: 'master' };
    }
}
