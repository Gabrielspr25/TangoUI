
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2, Upload, FileSpreadsheet } from 'lucide-react';

export default function DiscrepanciesPage() {
    const [file, setFile] = useState<File | null>(null);
    const [month, setMonth] = useState<string>('10');
    const [year, setYear] = useState<string>('2025');
    const [type, setType] = useState<string>('1');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const months = [
        { value: '1', label: 'Enero' },
        { value: '2', label: 'Febrero' },
        { value: '3', label: 'Marzo' },
        { value: '4', label: 'Abril' },
        { value: '5', label: 'Mayo' },
        { value: '6', label: 'Junio' },
        { value: '7', label: 'Julio' },
        { value: '8', label: 'Agosto' },
        { value: '9', label: 'Septiembre' },
        { value: '10', label: 'Octubre' },
        { value: '11', label: 'Noviembre' },
        { value: '12', label: 'Diciembre' },
    ];

    const reportTypes = [
        { value: '1', label: 'Discrepancia (Subsidios)' },
        { value: '2', label: 'Nuevas Activaciones' },
        { value: '3', label: 'Renovaciones' },
        { value: '4', label: 'Bonos Retención' },
        { value: '5', label: 'Prepago' },
    ];

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleProcess = async () => {
        if (!file) {
            setError('Por favor selecciona un archivo.');
            return;
        }

        setLoading(true);
        setError(null);

        const formData = new FormData();
        formData.append('file', file);
        formData.append('mes', month);
        formData.append('anio', year);
        formData.append('type', type);

        try {
            const response = await fetch('/api/discrepancies', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                throw new Error('Error al procesar el archivo');
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Reporte_${reportTypes.find(t => t.value === type)?.label.replace(/\s/g, '_')}_${year}_${month}.xlsx`;
            document.body.appendChild(a);
            a.click();
            a.remove();
        } catch (err) {
            setError('Ocurrió un error al procesar el reporte. Revisa la consola o intenta nuevamente.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container mx-auto py-10">
            <Card className="max-w-2xl mx-auto">
                <CardHeader>
                    <CardTitle className="text-2xl flex items-center gap-2">
                        <FileSpreadsheet className="h-6 w-6 text-blue-600" />
                        Conciliación de Discrepancias
                    </CardTitle>
                    <CardDescription>
                        Sube el archivo de importe del proveedor y selecciona el periodo para generar el reporte de conciliación.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="month">Mes</Label>
                            <Select value={month} onValueChange={setMonth}>
                                <SelectTrigger id="month">
                                    <SelectValue placeholder="Selecciona mes" />
                                </SelectTrigger>
                                <SelectContent>
                                    {months.map((m) => (
                                        <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="year">Año</Label>
                            <Input
                                id="year"
                                type="number"
                                value={year}
                                onChange={(e) => setYear(e.target.value)}
                                min="2020"
                                max="2030"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="type">Tipo de Reporte</Label>
                        <Select value={type} onValueChange={setType}>
                            <SelectTrigger id="type">
                                <SelectValue placeholder="Selecciona tipo" />
                            </SelectTrigger>
                            <SelectContent>
                                {reportTypes.map((t) => (
                                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="file">Archivo de Importe (.xls / .xlsx)</Label>
                        <div className="flex items-center gap-4">
                            <Input
                                id="file"
                                type="file"
                                accept=".xls,.xlsx"
                                onChange={handleFileChange}
                                className="cursor-pointer"
                            />
                        </div>
                        {file && <p className="text-sm text-muted-foreground mt-1">Archivo seleccionado: {file.name}</p>}
                    </div>

                    {error && (
                        <div className="p-3 bg-red-100 border border-red-200 text-red-700 rounded-md text-sm">
                            {error}
                        </div>
                    )}

                    <Button
                        onClick={handleProcess}
                        disabled={loading || !file}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Procesando...
                            </>
                        ) : (
                            <>
                                <Upload className="mr-2 h-4 w-4" />
                                Procesar y Descargar Reporte
                            </>
                        )}
                    </Button>

                </CardContent>
            </Card>
        </div>
    );
}
