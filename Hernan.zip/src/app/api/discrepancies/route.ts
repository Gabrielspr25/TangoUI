
import { NextRequest, NextResponse } from 'next/server';
import { DiscrepancyProcessor } from '@/lib/discrepancies/processor';
import ExcelJS from 'exceljs';
import { ReportData } from '@/lib/discrepancies/types';

export async function POST(req: NextRequest) {
    try {
        const formData = await req.formData();
        const file = formData.get('file') as File;
        const mes = parseInt(formData.get('mes') as string);
        const anio = parseInt(formData.get('anio') as string);
        const type = parseInt(formData.get('type') as string); // 1 = Discrepancies, 2 = New Activations, etc.

        if (!file || isNaN(mes) || isNaN(anio) || isNaN(type)) {
            return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
        }

        const buffer = Buffer.from(await file.arrayBuffer());
        const workbook = new ExcelJS.Workbook();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await workbook.xlsx.load(buffer as any);

        // Assume input data is in the first sheet and follows a structure we can map to ReportData
        const worksheet = workbook.getWorksheet(1);
        const data: ReportData[] = [];

        if (worksheet) {
            worksheet.eachRow((row, rowNumber) => {
                if (rowNumber > 1) { // Skip header
                    const rowVals = row.values as any[];
                    data.push({
                        emai: rowVals[1]?.toString() || '',
                        numero: rowVals[2]?.toString() || '',
                        fecha_activacion: rowVals[3]?.toString() || '',
                        ventatipoid: parseInt(rowVals[4] || '1'),
                        simcard: rowVals[5]?.toString(),
                        comisionclaro: rowVals[6]?.toString() || '0',
                        subsidio: rowVals[7]?.toString() || '0',
                        bonoportabilidad: rowVals[8]?.toString() || '0',
                        features: rowVals[9]?.toString() || '0',
                        comisionpapper: rowVals[10]?.toString() || '0',
                        numerocelularactivado: rowVals[2]?.toString() || ''
                    });
                }
            });
        }

        const processor = new DiscrepancyProcessor();
        let resultBuffer: Buffer;

        switch (type) {
            case 1: // Discrepancy (Subsidios)
                resultBuffer = await processor.generateDiscrepancyReport(data, mes, anio);
                break;
            case 2: // New Activations (Nuevas)
                resultBuffer = await processor.generateNewActivationsReport(data, mes, anio);
                break;
            default:
                resultBuffer = await processor.generateDiscrepancyReport(data, mes, anio);
        }

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return new NextResponse(resultBuffer as any, {
            status: 200,
            headers: {
                'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'Content-Disposition': `attachment; filename="report_processed.xlsx"`
            }
        });

    } catch (error) {
        console.error('Error processing discrepancy:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
