
import { NextRequest, NextResponse } from 'next/server';
import { DiscrepancyProcessor } from '@/lib/discrepancies/processor';
import { DiscrepancyModel } from '@/lib/discrepancies/model';

export async function GET(req: NextRequest) {
    try {
        const searchParams = req.nextUrl.searchParams;
        const mes = parseInt(searchParams.get('mes') || '');
        const anio = parseInt(searchParams.get('anio') || '');
        const type = parseInt(searchParams.get('type') || '1');

        if (isNaN(mes) || isNaN(anio) || isNaN(type)) {
            return NextResponse.json({ error: 'Missing or invalid parameters' }, { status: 400 });
        }

        const model = new DiscrepancyModel();
        // Fetch data from DB based on parameters
        const data = await model.getReportData(mes, anio, type);

        if (data.length === 0) {
            return NextResponse.json({ error: 'No records found for the specified period' }, { status: 404 });
        }

        const processor = new DiscrepancyProcessor();
        let resultBuffer: Buffer;

        switch (type) {
            case 1: // Discrepancy (Subsidios)
                resultBuffer = await processor.generateDiscrepancyReport(data, mes, anio);
                break;
            case 2: // New Activations (Nuevas)
                resultBuffer = await processor.generateNewActivationsReport(data, mes, anio);
                break;
            default:
                resultBuffer = await processor.generateDiscrepancyReport(data, mes, anio);
        }

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return new NextResponse(resultBuffer as any, {
            status: 200,
            headers: {
                'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'Content-Disposition': `attachment; filename="report_${type === 1 ? 'discrepancy' : 'activations'}_${anio}_${mes}.xlsx"`
            }
        });

    } catch (error) {
        console.error('Error generating download:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
