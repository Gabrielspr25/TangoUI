
import { NextRequest, NextResponse } from 'next/server';
import { DiscrepancyModel } from '@/lib/discrepancies/model';

// Use a singleton-like pattern or instantiate per request? 
// The model uses PrismaClient which handles connection pooling.
// Instantiating per request is fine.

export async function GET(req: NextRequest) {
    const searchParams = req.nextUrl.searchParams;
    const query = searchParams.get('q');

    if (!query) {
        return NextResponse.json({ error: 'Query parameter "q" is required' }, { status: 400 });
    }

    try {
        const model = new DiscrepancyModel();
        // Assuming the search method was added successfully
        const results = await model.search(query);

        // Convert BigInt to string for JSON serialization
        const serializedResults = JSON.parse(JSON.stringify(results, (key, value) =>
            typeof value === 'bigint'
                ? value.toString()
                : value // return everything else unchanged
        ));

        return NextResponse.json(serializedResults);
    } catch (error) {
        console.error('Search error:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
