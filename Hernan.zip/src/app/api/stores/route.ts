
import { NextResponse } from 'next/server';
import { getPrismaClient } from '@/lib/db-factory';

export async function GET() {
    try {
        const prisma = await getPrismaClient();
        const stores = await prisma.tienda.findMany({
            where: {
                tiendaactivo: true,
            },
            select: {
                tiendaid: true,
                nombre: true,
            },
            orderBy: {
                nombre: 'asc',
            },
        });

        const serializedStores = stores.map((store: any) => ({
            ...store,
            tiendaid: store.tiendaid.toString(),
        }));

        return NextResponse.json(serializedStores);
    } catch (error: any) {
        console.error('Error fetching stores:', error);
        const message = error.message?.includes("Can't reach database")
            ? "No se puede conectar al servidor de base de datos (Timeout/Unreachable)."
            : "Error al obtener las tiendas.";
        return NextResponse.json({ error: message }, { status: 500 });
    }
}
