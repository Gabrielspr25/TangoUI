
import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET() {
    try {
        const logPath = path.join(process.cwd(), 'activations.log');

        if (!fs.existsSync(logPath)) {
            return NextResponse.json([]);
        }

        const fileContent = fs.readFileSync(logPath, 'utf-8');
        // Parse NDJSON (Newline Delimited JSON)
        const logs = fileContent
            .split('\n')
            .filter(line => line.trim() !== '')
            .map(line => {
                try {
                    return JSON.parse(line);
                } catch (e) {
                    return null;
                }
            })
            .filter(item => item !== null)
            .reverse(); // Newest first

        return NextResponse.json(logs);

    } catch (error) {
        console.error('Error reading logs:', error);
        return NextResponse.json({ error: 'Failed to read logs' }, { status: 500 });
    }
}
