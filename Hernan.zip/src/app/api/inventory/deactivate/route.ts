
import { NextResponse } from 'next/server';
import { getPrismaClient } from '@/lib/db-factory';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { inventoryIds } = body;

        if (!Array.isArray(inventoryIds) || inventoryIds.length === 0) {
            return NextResponse.json({ error: 'No inventory IDs provided' }, { status: 400 });
        }

        const idsToUpdate = inventoryIds.map(id => BigInt(id));
        const prisma = await getPrismaClient();

        // 1. Verify items are currently active
        const itemsToUpdate = await prisma.inventario.findMany({
            where: {
                inventarioid: { in: idsToUpdate },
                activado: true
            },
            include: { equipo: true }
        });

        if (itemsToUpdate.length === 0) {
            return NextResponse.json({ message: 'No items found requiring deactivation' });
        }

        // 2. Perform Update (set activado = false)
        const updateResult = await prisma.inventario.updateMany({
            where: {
                inventarioid: { in: itemsToUpdate.map(i => i.inventarioid) }
            },
            data: {
                activado: false
            }
        });

        // 3. Log to File
        const logEntry = {
            timestamp: new Date().toISOString(),
            action: 'DEACTIVATE_NO_SALE',
            count: updateResult.count,
            items: itemsToUpdate.map(i => ({
                id: i.inventarioid.toString(),
                equipo: i.equipo?.nombre,
                serial: i.emai
            }))
        };

        const logPath = path.join(process.cwd(), 'deactivations.log');
        fs.appendFileSync(logPath, JSON.stringify(logEntry) + '\n');

        return NextResponse.json({
            success: true,
            count: updateResult.count,
            message: `Successfully deactivated ${updateResult.count} items.`
        });

    } catch (error) {
        console.error('Error deactivating inventory:', error);
        return NextResponse.json({ error: 'Failed to deactivate items' }, { status: 500 });
    }
}
