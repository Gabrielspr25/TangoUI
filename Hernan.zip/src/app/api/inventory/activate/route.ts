
import { NextResponse } from 'next/server';
import { getPrismaClient } from '@/lib/db-factory';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { inventoryIds } = body;

        if (!Array.isArray(inventoryIds) || inventoryIds.length === 0) {
            return NextResponse.json({ error: 'No inventory IDs provided' }, { status: 400 });
        }

        const idsToUpdate = inventoryIds.map(id => BigInt(id));
        const prisma = await getPrismaClient();

        // 1. Verify availability (Optional but good for safety)
        const itemsToUpdate = await prisma.inventario.findMany({
            where: {
                inventarioid: { in: idsToUpdate },
                activado: false
            },
            include: { equipo: true } // For logging details
        });

        if (itemsToUpdate.length === 0) {
            return NextResponse.json({ message: 'No items found requiring activation' });
        }

        // 2. Perform Update
        const updateResult = await prisma.inventario.updateMany({
            where: {
                inventarioid: { in: itemsToUpdate.map(i => i.inventarioid) }
            },
            data: {
                activado: true
            }
        });

        // 3. Log to File
        const logEntry = {
            timestamp: new Date().toISOString(),
            action: 'FIX_GHOST_INVENTORY',
            count: updateResult.count,
            items: itemsToUpdate.map(i => ({
                id: i.inventarioid.toString(),
                equipo: i.equipo?.nombre,
                serial: i.emai
            }))
        };

        const logPath = path.join(process.cwd(), 'activations.log');
        fs.appendFileSync(logPath, JSON.stringify(logEntry) + '\n');

        return NextResponse.json({
            success: true,
            count: updateResult.count,
            message: `Successfully activated ${updateResult.count} items.`
        });

    } catch (error) {
        console.error('Error activating inventory:', error);
        return NextResponse.json({ error: 'Failed to activate items' }, { status: 500 });
    }
}
