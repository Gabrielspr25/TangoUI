import { NextResponse } from 'next/server';
import { getPrismaClient } from '@/lib/db-factory';

export async function GET(request: Request) {
    const { searchParams } = new URL(request.url);
    const storeId = searchParams.get('storeId');

    if (!storeId) {
        return NextResponse.json({ error: 'Store ID is required' }, { status: 400 });
    }

    const activadoParam = searchParams.get('activado');
    const showSims = searchParams.get('showSims') === 'true';

    // UI "activado=true" means "En Stock" -> DB activado: false
    // UI "activado=false" means "Vendidos" -> DB activado: true
    const dbActivadoValue = activadoParam === 'true' ? false : true;

    try {
        const prisma = await getPrismaClient();
        console.log(`[API Inventory] Fetching for store ${storeId} using dynamic client.`);
        const inventory = await prisma.inventario.findMany({
            where: {
                tiendaid: BigInt(storeId),
                activado: dbActivadoValue,
                generico: false,
                ...(showSims ? {} : {
                    NOT: [
                        { equipo: { nombre: { contains: 'Simcard', mode: 'insensitive' } } },
                        { equipo: { nombre: { contains: 'Sim Card', mode: 'insensitive' } } },
                        { equipo: { nombre: { contains: 'Sim-Card', mode: 'insensitive' } } }
                    ]
                })
            },
            include: {
                equipo: {
                    select: {
                        equipoid: true,
                        nombre: true,
                        codigo: true,
                        costo: true,
                        activo: true,
                        controlstock: true,
                        externo: true,
                        // id_negocio: false // Excluded due to missing column in some DBs
                    }
                },
            },
            orderBy: {
                fechacompra: 'desc',
            },
            take: 10000,
        });

        const serializedInventory = inventory.map((item: any) => ({
            ...item,
            inventarioid: item.inventarioid.toString(),
            equipoid: item.equipoid?.toString(),
            tiendaid: item.tiendaid?.toString(),
            equipo: item.equipo ? {
                ...item.equipo,
                equipoid: item.equipo.equipoid.toString(),
                // id_negocio: item.equipo.id_negocio, // REMOVED
            } : null,
            precio: item.precio ? item.precio.toString() : '0',
        }));

        return NextResponse.json(serializedInventory);
    } catch (error: any) {
        console.error('Error fetching inventory:', error);
        // Extract useful message if possible, e.g. "Can't reach database server"
        const message = error.message?.includes("Can't reach database")
            ? "No se puede conectar al servidor de base de datos (Timeout/Unreachable)."
            : "Error al obtener el inventario.";

        return NextResponse.json({ error: message, details: error.message }, { status: 500 });
    }
}
