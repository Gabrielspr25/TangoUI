import { NextResponse } from 'next/server';
import { getPrismaClient } from '@/lib/db-factory';

export async function GET(request: Request) {
    const { searchParams } = new URL(request.url);
    const storeId = searchParams.get('storeId');

    if (!storeId) {
        return NextResponse.json({ error: 'Store ID is required' }, { status: 400 });
    }

    const showSims = searchParams.get('showSims') === 'true';

    try {
        // Fetch all active inventory items for the store
        // activado: false means "En Stock"
        const prisma = await getPrismaClient();
        const inventory = await prisma.inventario.findMany({
            where: {
                tiendaid: BigInt(storeId),
                activado: false,
                generico: false,
                ...(showSims ? {} : {
                    NOT: {
                        equipo: {
                            nombre: {
                                contains: 'Simcard',
                                mode: 'insensitive'
                            }
                        }
                    }
                })
            },
            include: {
                equipo: true,
            },
        });

        // Group by equipment name
        const summaryMap = new Map<string, number>();

        inventory.forEach((item) => {
            const name = item.equipo?.nombre || 'Desconocido';
            summaryMap.set(name, (summaryMap.get(name) || 0) + 1);
        });

        // Convert to array and sort by name
        const summary = Array.from(summaryMap.entries())
            .map(([name, count]) => ({ name, count }))
            .sort((a, b) => a.name.localeCompare(b.name));

        return NextResponse.json(summary);
    } catch (error) {
        console.error('Error fetching inventory summary:', error);
        return NextResponse.json({ error: 'Failed to fetch inventory summary' }, { status: 500 });
    }
}
