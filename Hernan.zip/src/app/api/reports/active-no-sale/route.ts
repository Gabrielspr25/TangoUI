
import { NextResponse } from 'next/server';
import { getPrismaClient } from '@/lib/db-factory';

export async function GET() {
    try {
        // Find items that are marked as sold (activado = true) in inventory
        // BUT have NO corresponding active sale in venta table

        const results = await prisma.$queryRaw`
            SELECT 
                i.inventarioid,
                i.emai as serial,
                i.activado,
                i.fechacompra,
                i.precio,
                e.nombre as equipo_nombre,
                e.codigo as equipo_codigo,
                t.nombre as tienda_nombre
            FROM inventario i
            LEFT JOIN equipo e ON i.equipoid = e.equipoid
            LEFT JOIN tienda t ON i.tiendaid = t.tiendaid
            LEFT JOIN venta v ON (i.emai = v.emai OR i.emai = v.simcard) AND v.activo = true
            WHERE i.activado = true
              AND i.generico = false
              AND v.ventaid IS NULL
            ORDER BY i.fechacompra DESC
            LIMIT 200
        `;

        // Serialize BigInts
        const serialized = (results as any[]).map((item: any) => {
            const isSim = item.equipo_nombre?.toLowerCase().includes('simcard');

            return {
                inventarioid: item.inventarioid?.toString(),
                nombre: item.equipo_nombre || 'Unknown',
                codigo: item.equipo_codigo || '-',
                serial: item.serial || '-',
                tienda: item.tienda_nombre || 'N/A',
                precio: item.precio?.toString() || '0',
                fechacompra: item.fechacompra,
                isSim
            };
        });

        return NextResponse.json(serialized);
    } catch (error) {
        console.error('Error fetching active-no-sale report:', error);
        return NextResponse.json({ error: 'Failed to fetch report' }, { status: 500 });
    }
}
