
import { NextResponse } from 'next/server';
import { getPrismaClient } from '@/lib/db-factory';

export async function GET(request: Request) {
    // No longer filtering by store - showing global discrepancies

    try {
        // Find items that are in an active sale (venta.activo = true)
        // AND correspond to an inventory item that is inactive (inventario.activado = false)
        // using Raw SQL because 'venta' and 'inventario' are linked by 'emai' string field, not a foreign key.

        const prisma = await getPrismaClient();

        const results = await prisma.$queryRaw`
            (
                SELECT 
                    v.ventaid, 
                    v.fechaactivacion as fecha, 
                    v.emai as serial, 
                    v.simcard as simcard, 
                    v.numerocelularactivado as telefono, 
                    i.inventarioid, 
                    i.activado, 
                    e.nombre as equipo_nombre, 
                    e.codigo as equipo_codigo, 
                    t.nombre as tienda_nombre
                FROM venta v
                JOIN inventario i ON v.emai = i.emai
                LEFT JOIN equipo e ON i.equipoid = e.equipoid
                LEFT JOIN tienda t ON v.tiendaid = t.tiendaid
                WHERE v.activo = true
                  AND i.activado = false
                  AND i.generico = false
                  AND e.nombre NOT ILIKE '%Simcard%'
                LIMIT 100
            )
            UNION ALL
            (
                SELECT 
                    v.ventaid, 
                    v.fechaactivacion as fecha, 
                    v.emai as serial, 
                    v.simcard as simcard, 
                    v.numerocelularactivado as telefono, 
                    i.inventarioid, 
                    i.activado, 
                    e.nombre as equipo_nombre, 
                    e.codigo as equipo_codigo, 
                    t.nombre as tienda_nombre
                FROM venta v
                JOIN inventario i ON v.simcard = i.emai
                LEFT JOIN equipo e ON i.equipoid = e.equipoid
                LEFT JOIN tienda t ON v.tiendaid = t.tiendaid
                WHERE v.activo = true
                  AND i.activado = false
                  AND i.generico = false
                  AND v.simcard IS NOT NULL 
                  AND v.simcard != ''
                  AND e.nombre ILIKE '%Simcard%'
                LIMIT 100
            )
            ORDER BY fecha DESC
            LIMIT 200
        `;

        // Serialize BigInts
        const serialized = (results as any[]).map((item: any, index: number) => {
            const isSim = item.equipo_nombre?.toLowerCase().includes('simcard');

            // Debug first few items
            if (index < 3) {
                console.log(`Debug Item ${index}:`, {
                    name: item.equipo_nombre,
                    isSim,
                    emai_serial: item.serial,
                    db_simcard: item.simcard
                });
            }

            return {
                ventaproductoid: item.ventaid?.toString(),
                fecha: item.fecha,
                inventarioid: item.inventarioid?.toString(),
                nombre: item.equipo_nombre || 'Unknown',
                codigo: item.equipo_codigo || '-',
                serial: isSim ? (item.simcard || item.serial) : item.serial,
                telefono: item.telefono?.toString() || '-',
                active_sale_id: item.ventaid?.toString(),
                sale_active: true,
                inventory_active: false,
                tienda: item.tienda_nombre || 'N/A'
            };
        });

        return NextResponse.json(serialized);
    } catch (error) {
        console.error('Error fetching report:', error);
        return NextResponse.json({ error: 'Failed to fetch report' }, { status: 500 });
    }
}
