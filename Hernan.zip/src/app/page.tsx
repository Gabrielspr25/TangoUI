'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Icons } from "@/components/icons"
import { cn } from "@/lib/utils"
import { Sidebar } from "@/components/sidebar"
import { MetricCard } from "@/components/metric-card"
import { DiscrepanciesView } from "@/components/discrepancies-view"
import { ConfigurationView } from "@/components/configuration-view"
import { getConnectionInfo } from "@/actions/connection"

interface Store {
  tiendaid: string;
  nombre: string;
}

interface InventoryItem {
  inventarioid: string;
  equipoid: string;
  emai: string;
  fechacompra: string;
  precio: string;
  tiendaid: string;
  equipo: {
    nombre: string;
    codigo: string;
  } | null;
}

export default function Home() {
  const [stores, setStores] = useState<Store[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [reportItems, setReportItems] = useState<any[]>([]);
  const [activeNoSaleItems, setActiveNoSaleItems] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'inventory' | 'report' | 'active-no-sale' | 'audit' | 'discrepancies' | 'configuration'>('inventory');
  const [selectedStore, setSelectedStore] = useState('');
  const [showSims, setShowSims] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [darkMode, setDarkMode] = useState(false);
  const [connectionInfo, setConnectionInfo] = useState({ name: 'Master', id: 'master' });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getConnectionInfo().then(setConnectionInfo);
  }, []);

  // Audit State
  const [scannedImeis, setScannedImeis] = useState<Set<string>>(new Set());
  const [scanInput, setScanInput] = useState('');
  const [auditFinished, setAuditFinished] = useState(false);

  // Logs State
  const [showLogs, setShowLogs] = useState(false);
  const [logs, setLogs] = useState<any[]>([]);

  const [summaryItems, setSummaryItems] = useState<{ name: string, count: number }[]>([]);

  // New Inventory View State
  const [inventoryView, setInventoryView] = useState<'detail' | 'summary'>('detail');
  const [summarySearch, setSummarySearch] = useState('');
  const [summarySort, setSummarySort] = useState<{ field: 'name' | 'count', direction: 'asc' | 'desc' }>({ field: 'name', direction: 'asc' });
  const [detailSort, setDetailSort] = useState<{ field: 'equipo' | 'codigo' | 'emai' | 'precio' | 'fecha', direction: 'asc' | 'desc' }>({ field: 'fecha', direction: 'desc' });

  useEffect(() => {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
    }
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    fetch('/api/stores')
      .then((res) => res.json())
      .then((data) => {
        if (!Array.isArray(data)) {
          console.error("API /api/stores returned non-array:", data);
          setError(data.error || "Error de conexión con la base de datos.");
          return;
        }
        setError(null);
        setStores(data);
        const plazaDorada = data.find((s: Store) => s.tiendaid === '2');
        if (plazaDorada) setSelectedStore('2');
        else if (data.length > 0) setSelectedStore(data[0].tiendaid);
      })
      .catch((err) => console.error(err));
  }, []);

  useEffect(() => {
    if (!selectedStore) return;

    if (activeTab === 'report') {
      setLoading(true);
      fetch(`/api/reports/sold-items?_t=${Date.now()}`, { cache: 'no-store' })
        .then((res) => res.json())
        .then((data) => {
          setReportItems(Array.isArray(data) ? data : []);
          setLoading(false);
        })
        .catch((err) => { console.error(err); setLoading(false); });
    } else if (activeTab === 'active-no-sale') {
      setLoading(true);
      fetch(`/api/reports/active-no-sale?_t=${Date.now()}`, { cache: 'no-store' })
        .then((res) => res.json())
        .then((data) => {
          setActiveNoSaleItems(Array.isArray(data) ? data : []);
          setLoading(false);
        })
        .catch((err) => { console.error(err); setLoading(false); });
    } else if (activeTab === 'inventory' && inventoryView === 'summary') {
      setLoading(true);
      fetch(`/api/reports/inventory-summary?storeId=${selectedStore}&showSims=${showSims}`, { cache: 'no-store' })
        .then((res) => res.json())
        .then((data) => {
          setSummaryItems(Array.isArray(data) ? data : []);
          setLoading(false);
        })
        .catch((err) => { console.error(err); setLoading(false); });
    } else {
      const statusFilter = activeTab === 'audit' ? 'true' : 'true';
      setLoading(true);
      setLoadingProgress(0);

      const interval = setInterval(() => {
        setLoadingProgress(prev => Math.min(prev + 5, 90));
      }, 100);

      fetch(`/api/inventory?storeId=${selectedStore}&activado=${statusFilter}&showSims=${showSims}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.error) throw new Error(data.error);
          setItems(data);
          setLoadingProgress(100);
          setTimeout(() => setLoading(false), 200);
          clearInterval(interval);
        })
        .catch((err) => {
          console.error(err);
          setError(err.message || "Error cargando inventario");
          setLoading(false);
          clearInterval(interval);
        });

      return () => clearInterval(interval);
    }
  }, [selectedStore, showSims, activeTab, inventoryView]);

  const handleScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scanInput.trim()) return;
    setScannedImeis(prev => new Set(prev).add(scanInput.trim()));
    setScanInput('');
  };

  const activateItems = async (ids: string[]) => {
    if (!confirm(`¿Activar ${ids.length} items?`)) return;
    setLoading(true);
    try {
      await fetch('/api/inventory/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inventoryIds: ids })
      });
      const reportRes = await fetch(`/api/reports/sold-items?_t=${Date.now()}`, { cache: 'no-store' });
      const reportData = await reportRes.json();
      setReportItems(Array.isArray(reportData) ? reportData : []);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  };

  const deactivateItems = async (ids: string[]) => {
    if (!confirm(`¿Desactivar ${ids.length} items?`)) return;
    setLoading(true);
    try {
      await fetch('/api/inventory/deactivate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inventoryIds: ids })
      });
      const reportRes = await fetch(`/api/reports/active-no-sale?_t=${Date.now()}`, { cache: 'no-store' });
      const reportData = await reportRes.json();
      setActiveNoSaleItems(Array.isArray(reportData) ? reportData : []);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/logs/activations');
      const data = await res.json();
      setLogs(data);
      setShowLogs(true);
    } catch (err) { console.error(err); }
  };

  const totalValue = items.reduce((sum, item) => sum + parseFloat(item.precio || '0'), 0);

  const getSortedDetailItems = () => {
    let result = [...items];

    // UI Filter for SIM cards (Double check in case API missed some)
    if (!showSims) {
      result = result.filter(item => {
        const name = item.equipo?.nombre?.toLowerCase() || '';
        return !name.includes('simcard') && !name.includes('sim card') && !name.includes('sim-card');
      });
    }

    result.sort((a, b) => {
      const field = detailSort.field;
      const direction = detailSort.direction === 'asc' ? 1 : -1;

      switch (field) {
        case 'equipo':
          return (a.equipo?.nombre || '').localeCompare(b.equipo?.nombre || '') * direction;
        case 'codigo':
          return (a.equipo?.codigo || '').localeCompare(b.equipo?.codigo || '') * direction;
        case 'emai':
          return (a.emai || '').localeCompare(b.emai || '') * direction;
        case 'precio':
          return (parseFloat(a.precio || '0') - parseFloat(b.precio || '0')) * direction;
        case 'fecha':
          return (new Date(a.fechacompra || 0).getTime() - new Date(b.fechacompra || 0).getTime()) * direction;
        default:
          return 0;
      }
    });
    return result;
  };

  const filteredItems = getSortedDetailItems();
  const scannedItems = items.filter(item => scannedImeis.has(item.emai));
  const missingItems = items.filter(item => !scannedImeis.has(item.emai));

  const getSortedSummary = () => {
    let result = [...summaryItems];
    if (summarySearch) {
      result = result.filter(i => i.name.toLowerCase().includes(summarySearch.toLowerCase()));
    }
    result.sort((a, b) => {
      const field = summarySort.field;
      const direction = summarySort.direction === 'asc' ? 1 : -1;
      if (field === 'name') return a.name.localeCompare(b.name) * direction;
      return (a.count - b.count) * direction;
    });
    return result;
  };
  const sortedSummaryItems = getSortedSummary();

  const handleSort = (field: 'name' | 'count') => {
    setSummarySort(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const getAuditSortedItems = () => {
    const auditItems = [...items];
    return auditItems.sort((a, b) => {
      const aScanned = scannedImeis.has(a.emai);
      const bScanned = scannedImeis.has(b.emai);
      if (aScanned === bScanned) return 0;
      return aScanned ? 1 : -1; // Scanned items go to bottom
    });
  };

  const handleExportAudit = () => {
    const sorted = getAuditSortedItems();

    let html = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="UTF-8">
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>Control de Inventario</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          table { border-collapse: collapse; width: 100%; }
          th { background-color: #f3f4f6; border: 1px solid #d1d5db; padding: 8px; text-align: left; }
          td { border: 1px solid #d1d5db; padding: 8px; }
          .scanned { background-color: #d1fae5; color: #065f46; font-weight: bold; }
          .missing { color: #991b1b; }
        </style>
      </head>
      <body>
        <table>
          <thead>
            <tr>
              <th>Tienda</th>
              <th>Equipo</th>
              <th>Código</th>
              <th>IMEI / Serial</th>
              <th>Precio</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
    `;

    sorted.forEach(item => {
      const isScanned = scannedImeis.has(item.emai);
      const storeName = stores.find(s => s.tiendaid === item.tiendaid)?.nombre || item.tiendaid;
      const cssClass = isScanned ? 'scanned' : 'missing';
      const statusText = isScanned ? 'ENCONTRADO' : 'FALTANTE';

      html += `
        <tr class="${isScanned ? 'scanned' : ''}">
          <td>${storeName}</td>
          <td>${item.equipo?.nombre}</td>
          <td style="mso-number-format:'@'">${item.equipo?.codigo}</td>
          <td style="mso-number-format:'@'">${item.emai}</td>
          <td>${parseFloat(item.precio || '0').toFixed(2)}</td>
          <td class="${cssClass}">${statusText}</td>
        </tr>
      `;
    });

    html += `
          </tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
    const url = window.URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `Control_Inventario_${new Date().toISOString().split('T')[0]}.xls`;
    anchor.click();
    window.URL.revokeObjectURL(url);
  };

  const auditSortedItems = activeTab === 'audit' ? getAuditSortedItems() : [];

  const handleDetailSort = (field: 'equipo' | 'codigo' | 'emai' | 'precio' | 'fecha') => {
    setDetailSort(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  // Safe navigation function
  const handleTabChange = (newTab: 'inventory' | 'audit' | 'report' | 'active-no-sale' | 'discrepancies' | 'configuration') => {
    setActiveTab(newTab);
    // Reset secondary views when changing main tabs
    setActiveTab(newTab);
    // Reset secondary views when changing main tabs
    if (newTab === 'inventory') {
      if (inventoryView !== 'detail') setInventoryView('detail');
    }
  };

  return (
    <div className="flex min-h-screen bg-background text-foreground transition-colors duration-300">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={handleTabChange}
        className="hidden md:block w-64 shrink-0"
        connectionName={connectionInfo.name}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-16 shrink-0 border-b flex items-center justify-between px-8 bg-card">
          <div className="flex items-center gap-2 text-sm breadcrumbs text-muted-foreground">
            <span className="font-semibold text-foreground">
              {activeTab === 'inventory' && 'Inventario General'}
              {activeTab === 'audit' && 'Auditoría de Stock'}
              {activeTab === 'report' && 'Reporte: Ventas sin Registro'}
              {activeTab === 'active-no-sale' && 'Reporte: Activo sin Venta'}
              {activeTab === 'discrepancies' && 'Conciliación de Discrepancias'}
              {activeTab === 'configuration' && 'Sistema'}
            </span>
            {selectedStore && activeTab !== 'configuration' && (
              <>
                <span>/</span>
                <span>{stores.find(s => s.tiendaid === selectedStore)?.nombre}</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-4">
            <select
              value={selectedStore}
              onChange={(e) => setSelectedStore(e.target.value)}
              className="h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm ring-offset-background focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            >
              {stores.map(s => <option key={s.tiendaid} value={s.tiendaid}>{s.nombre}</option>)}
            </select>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setDarkMode(!darkMode)}
            >
              {darkMode ? <Icons.sun className="h-5 w-5" /> : <Icons.moon className="h-5 w-5" />}
            </Button>
          </div>
        </header>

        {/* Scrollable Content */}
        <main className="flex-1 overflow-auto p-8 space-y-8">

          {error && (
            <div className="bg-destructive/15 text-destructive px-4 py-3 rounded-lg border border-destructive/20 flex items-center gap-2">
              <Icons.alert className="h-5 w-5" />
              <p className="font-medium">{error}</p>
            </div>
          )}

          {/* Dashboard Cards (Only for Inventory View) */}
          {activeTab === 'inventory' && inventoryView === 'detail' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <MetricCard
                title="Valor Total Inventario"
                value={`$${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
                icon={Icons.chart}
              />
              <MetricCard
                title="Total Dispositivos"
                value={filteredItems.length.toString()}
                icon={Icons.smartphone}
              />
              <MetricCard
                title="Discrepancias"
                value={(reportItems.length + activeNoSaleItems.length).toString()}
                subtext="Requieren atención inmediata"
                icon={Icons.alert}
                trend={{ value: "Acción requerida", isPositive: false }}
              />
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center gap-4 bg-muted/30 p-4 rounded-xl border border-primary/20">
                <div className="flex-1">
                  <form onSubmit={handleScan} className="flex gap-4">
                    <Input
                      autoFocus
                      value={scanInput}
                      onChange={(e) => setScanInput(e.target.value)}
                      placeholder="Escanear IMEI / Serial..."
                      className="flex-1 text-lg font-mono h-12 bg-background"
                    />
                    <Button type="submit" size="lg" className="h-12 px-8">
                      Agregar
                    </Button>
                  </form>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-xs font-bold uppercase text-muted-foreground">Progreso</p>
                    <p className="text-xl font-black">
                      <span className="text-emerald-500">{scannedImeis.size}</span>
                      <span className="text-muted-foreground opacity-40"> / {items.length}</span>
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="h-12 border-emerald-500/50 text-emerald-600 hover:bg-emerald-500/10"
                    onClick={handleExportAudit}
                  >
                    <Icons.fileText className="mr-2 h-4 w-4" />
                    Exportar Excel
                  </Button>
                </div>
              </div>

              <div className="rounded-md border bg-card">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Equipo</TableHead>
                      <TableHead>Código</TableHead>
                      <TableHead>Serial / IMEI</TableHead>
                      <TableHead className="text-right">Precio</TableHead>
                      <TableHead className="text-center">Estado</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditSortedItems.map(item => {
                      const isScanned = scannedImeis.has(item.emai);
                      return (
                        <TableRow
                          key={item.inventarioid}
                          className={cn(
                            "transition-colors",
                            isScanned ? "bg-emerald-500/10 hover:bg-emerald-500/20" : ""
                          )}
                        >
                          <TableCell className="font-bold py-1">{item.equipo?.nombre}</TableCell>
                          <TableCell className="font-mono text-xs opacity-50 py-1">{item.equipo?.codigo}</TableCell>
                          <TableCell className="py-1">
                            <Badge variant="secondary" className="font-mono font-normal">
                              {item.emai}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-bold opacity-70 py-1">
                            ${parseFloat(item.precio || '0').toFixed(2)}
                          </TableCell>
                          <TableCell className="text-center py-1">
                            {isScanned ? (
                              <Badge className="bg-emerald-500 hover:bg-emerald-600">ENCONTRADO</Badge>
                            ) : (
                              <Badge variant="outline" className="text-muted-foreground opacity-50">PENDIENTE</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}

          {loading ? (
            <div className="flex flex-col items-center justify-center h-64">
              <div className="w-48 h-1.5 rounded-full overflow-hidden bg-muted">
                <div className="h-full bg-primary transition-all duration-300" style={{ width: `${loadingProgress}%` }} />
              </div>
              <p className="mt-4 text-sm font-medium animate-pulse text-muted-foreground tracking-widest uppercase">
                Cargando {loadingProgress}%
              </p>
            </div>
          ) : activeTab === 'configuration' ? (
            <ConfigurationView currentConnectionId={connectionInfo.id} />
          ) : activeTab === 'inventory' ? (
            <div className="space-y-6">
              <div className="flex flex-wrap justify-between items-center gap-4">
                <div className="flex gap-1 bg-muted/50 p-1 rounded-lg">
                  <Button
                    variant={inventoryView === 'detail' ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setInventoryView('detail')}
                  >
                    Detalle
                  </Button>
                  <Button
                    variant={inventoryView === 'summary' ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setInventoryView('summary')}
                  >
                    Resumen
                  </Button>
                </div>

                {inventoryView === 'detail' ? (
                  <div className="flex gap-2">
                    <Button
                      variant={showSims ? "default" : "outline"}
                      size="sm"
                      onClick={() => setShowSims(!showSims)}
                    >
                      {showSims ? 'Ocultar' : 'Mostrar'} SIMs
                    </Button>
                  </div>
                ) : (
                  <div className="flex-1 max-w-md ml-4">
                    <div className="relative">
                      <Icons.search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Buscar modelo..."
                        value={summarySearch}
                        onChange={(e) => setSummarySearch(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                )}
              </div>


              {inventoryView === 'detail' ? (
                <div className="rounded-md border bg-card">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead
                          className="w-[50%] cursor-pointer hover:text-primary transition-colors select-none"
                          onClick={() => handleDetailSort('equipo')}
                        >
                          Equipo {detailSort.field === 'equipo' && (
                            detailSort.direction === 'asc' ? <Icons.chevronUp className="inline ml-1 h-3 w-3" /> : <Icons.chevronDown className="inline ml-1 h-3 w-3" />
                          )}
                        </TableHead>
                        <TableHead
                          className="cursor-pointer hover:text-primary transition-colors select-none"
                          onClick={() => handleDetailSort('codigo')}
                        >
                          Código {detailSort.field === 'codigo' && (
                            detailSort.direction === 'asc' ? <Icons.chevronUp className="inline ml-1 h-3 w-3" /> : <Icons.chevronDown className="inline ml-1 h-3 w-3" />
                          )}
                        </TableHead>
                        <TableHead
                          className="cursor-pointer hover:text-primary transition-colors select-none"
                          onClick={() => handleDetailSort('emai')}
                        >
                          Serial / IMEI {detailSort.field === 'emai' && (
                            detailSort.direction === 'asc' ? <Icons.chevronUp className="inline ml-1 h-3 w-3" /> : <Icons.chevronDown className="inline ml-1 h-3 w-3" />
                          )}
                        </TableHead>
                        <TableHead
                          className="text-right cursor-pointer hover:text-primary transition-colors select-none"
                          onClick={() => handleDetailSort('precio')}
                        >
                          Precio {detailSort.field === 'precio' && (
                            detailSort.direction === 'asc' ? <Icons.chevronUp className="inline ml-1 h-3 w-3" /> : <Icons.chevronDown className="inline ml-1 h-3 w-3" />
                          )}
                        </TableHead>
                        <TableHead
                          className="text-center cursor-pointer hover:text-primary transition-colors select-none"
                          onClick={() => handleDetailSort('fecha')}
                        >
                          Compra {detailSort.field === 'fecha' && (
                            detailSort.direction === 'asc' ? <Icons.chevronUp className="inline ml-1 h-3 w-3" /> : <Icons.chevronDown className="inline ml-1 h-3 w-3" />
                          )}
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.map(item => (
                        <TableRow key={item.inventarioid} className="group">
                          <TableCell className="font-bold group-hover:text-primary transition-colors py-1">
                            {item.equipo?.nombre}
                          </TableCell>
                          <TableCell className="font-mono text-xs opacity-50 py-1">{item.equipo?.codigo}</TableCell>
                          <TableCell className="py-1">
                            <Badge variant="secondary" className="font-mono font-normal">
                              {item.emai}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-bold text-emerald-500 py-1">
                            ${parseFloat(item.precio || '0').toFixed(2)}
                          </TableCell>
                          <TableCell className="text-center text-xs opacity-50 py-1">
                            {item.fechacompra ? new Date(item.fechacompra).toLocaleDateString() : '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredItems.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={5} className="h-24 text-center">
                            No hay registros para mostrar
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="rounded-md border bg-card">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead
                          className="cursor-pointer hover:text-foreground transition-colors select-none"
                          onClick={() => handleSort('name')}
                        >
                          Modelo / Equipo {summarySort.field === 'name' && (
                            summarySort.direction === 'asc'
                              ? <Icons.chevronUp className="inline ml-1 h-3 w-3" />
                              : <Icons.chevronDown className="inline ml-1 h-3 w-3" />
                          )}
                        </TableHead>
                        <TableHead
                          className="cursor-pointer hover:text-foreground transition-colors select-none text-right w-32"
                          onClick={() => handleSort('count')}
                        >
                          Cantidad {summarySort.field === 'count' && (
                            summarySort.direction === 'asc'
                              ? <Icons.chevronUp className="inline ml-1 h-3 w-3" />
                              : <Icons.chevronDown className="inline ml-1 h-3 w-3" />
                          )}
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedSummaryItems.map((item, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-bold py-1">{item.name}</TableCell>
                          <TableCell className="text-right py-1">
                            <Badge variant="amber" className="text-sm px-3">
                              {item.count}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                      {sortedSummaryItems.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={2} className="h-24 text-center">
                            No hay inventario disponible
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>

          ) : (activeTab === 'report' || activeTab === 'active-no-sale') ? (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-black flex items-center gap-2">
                  <div className={`w-2 h-8 rounded-full ${activeTab === 'report' ? 'bg-destructive' : 'bg-blue-500'}`} />
                  {activeTab === 'report' ? 'Ventas sin Registro de Inventario' : 'Inventario Activo sin Venta Real'}
                </h2>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    onClick={() => showLogs ? setShowLogs(false) : fetchLogs()}
                  >
                    <Icons.history className="mr-2 h-4 w-4" />
                    Logs
                  </Button>
                  {(activeTab === 'report' ? reportItems : activeNoSaleItems).length > 0 && (
                    <Button
                      variant={activeTab === 'report' ? "emerald" as any : "default"}
                      onClick={() => activeTab === 'report' ? activateItems(reportItems.map(i => i.inventarioid)) : deactivateItems(activeNoSaleItems.map(i => i.inventarioid))}
                      className={activeTab === 'report' ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-blue-600 hover:bg-blue-700 text-white"}
                    >
                      Corregir Todos ({(activeTab === 'report' ? reportItems : activeNoSaleItems).length})
                    </Button>
                  )}
                </div>
              </div>

              {showLogs && (
                <Card className="bg-muted/10 border-primary/20">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium opacity-50 uppercase tracking-widest">
                      Historial de Acciones
                    </CardTitle>
                    <Button variant="ghost" size="sm" onClick={() => setShowLogs(false)}>
                      Cerrar
                    </Button>
                  </CardHeader>
                  <CardContent className="max-h-60 overflow-y-auto space-y-2">
                    {logs.map((L, i) => (
                      <div key={i} className="p-3 rounded-lg border bg-card flex justify-between items-center text-xs border-l-2 border-l-primary">
                        <div className="flex gap-4">
                          <span className="font-mono opacity-40">{new Date(L.timestamp).toLocaleString()}</span>
                          <span className="font-bold text-emerald-500">{L.action}</span>
                          <span className="opacity-60">{L.count} items</span>
                        </div>
                        <span className="font-mono opacity-30 truncate max-w-[200px]">{L.items?.map((it: any) => it.equipo).join(', ')}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              <div className="rounded-md border bg-card">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tienda</TableHead>
                      <TableHead>Equipo / Modelo</TableHead>
                      <TableHead>Serial / IMEI</TableHead>
                      <TableHead>Fecha Detectada</TableHead>
                      <TableHead className="text-right">Acción</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(activeTab === 'report' ? reportItems : activeNoSaleItems).map((item, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="font-bold text-muted-foreground">{item.tienda}</TableCell>
                        <TableCell className="font-medium">{item.equipo}</TableCell>
                        <TableCell className="font-mono text-sm opacity-80">{item.emai}</TableCell>
                        <TableCell className="text-xs opacity-60">
                          {new Date(item.fecha).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant={activeTab === 'report' ? "emerald" as any : "default"} // Custom variant hack or use default with class
                            onClick={() => activeTab === 'report' ? activateItems([item.inventarioid]) : deactivateItems([item.inventarioid])}
                            className={activeTab === 'report' ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-blue-600 hover:bg-blue-700 text-white"}
                          >
                            {activeTab === 'report' ? 'Activar (Fix)' : 'Desactivar (Fix)'}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {(activeTab === 'report' ? reportItems : activeNoSaleItems).length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          <div className="flex flex-col items-center justify-center opacity-40">
                            <Icons.check className="h-8 w-8 mb-2" />
                            <p>Todo está en orden</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          ) : activeTab === 'discrepancies' ? (
            <DiscrepanciesView />
          ) : null}
        </main>
      </div >
    </div >
  );
}
