'use client';

import { useEffect, useState } from 'react';
import { getClientList, switchConnection } from '@/actions/connection';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle2, Circle } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface Client {
    id: string;
    nombre: string;
}

export default function ConfiguracionPage() {
    const [clients, setClients] = useState<Client[]>([]);
    const [activeClientId, setActiveClientId] = useState<string | null>(null); // 'master' or ID
    const [loading, setLoading] = useState(true);
    const [switching, setSwitching] = useState<string | null>(null);
    const router = useRouter();

    useEffect(() => {
        async function load() {
            try {
                const list = await getClientList();
                setClients(list);

                // Simple way to get active client from cookie in client component
                // In a real app we might pass this as a prop or context
                const match = document.cookie
                    .split('; ')
                    .find(row => row.startsWith('active_client='));

                const current = match ? match.split('=')[1] : 'master';
                setActiveClientId(current);
            } catch (err) {
                console.error("Failed to load clients", err);
            } finally {
                setLoading(false);
            }
        }
        load();
    }, []);

    const handleConnect = async (clientId: string) => {
        setSwitching(clientId);
        try {
            await switchConnection(clientId);
            setActiveClientId(clientId);
            router.refresh(); // Refresh to update server components
        } catch (err) {
            console.error("Failed to switch", err);
            alert("Error al conectar");
        } finally {
            setSwitching(null);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }

    return (
        <div className="p-8 max-w-4xl mx-auto space-y-8">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Configuración</h1>
                <p className="text-muted-foreground mt-2">
                    Administra las conexiones a las bases de datos de los clientes.
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Conexiones Disponibles</CardTitle>
                    <CardDescription>
                        Selecciona la base de datos a la que deseas conectarte.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">

                        {/* Master Connection */}
                        <div className={`flex items-center justify-between p-4 rounded-lg border ${activeClientId === 'master' ? 'bg-primary/5 border-primary' : 'bg-card'}`}>
                            <div className="flex items-center gap-4">
                                {activeClientId === 'master' ? (
                                    <CheckCircle2 className="h-5 w-5 text-primary" />
                                ) : (
                                    <Circle className="h-5 w-5 text-muted-foreground" />
                                )}
                                <div>
                                    <p className="font-medium">Master (Default)</p>
                                    <p className="text-sm text-muted-foreground">Base de datos principal</p>
                                </div>
                            </div>
                            <Button
                                variant={activeClientId === 'master' ? "secondary" : "default"}
                                onClick={() => handleConnect('master')}
                                disabled={activeClientId === 'master' || !!switching}
                            >
                                {switching === 'master' && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {activeClientId === 'master' ? "Conectado" : "Conectar"}
                            </Button>
                        </div>

                        {/* Client Connections */}
                        {clients.map(client => (
                            <div key={client.id} className={`flex items-center justify-between p-4 rounded-lg border ${activeClientId === client.id ? 'bg-primary/5 border-primary' : 'bg-card'}`}>
                                <div className="flex items-center gap-4">
                                    {activeClientId === client.id ? (
                                        <CheckCircle2 className="h-5 w-5 text-primary" />
                                    ) : (
                                        <Circle className="h-5 w-5 text-muted-foreground" />
                                    )}
                                    <div>
                                        <p className="font-medium">{client.nombre}</p>
                                        <p className="text-sm text-muted-foreground">ID: {client.id}</p>
                                    </div>
                                </div>
                                <Button
                                    variant={activeClientId === client.id ? "secondary" : "default"}
                                    onClick={() => handleConnect(client.id)}
                                    disabled={activeClientId === client.id || !!switching}
                                >
                                    {switching === client.id && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    {activeClientId === client.id ? "Conectado" : "Conectar"}
                                </Button>
                            </div>
                        ))}

                        {clients.length === 0 && (
                            <p className="text-center text-muted-foreground py-8">
                                No se encontraron otros clientes configurados en bbddclientes.
                            </p>
                        )}

                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
