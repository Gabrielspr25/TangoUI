import { useState } from "react"
import { ChevronDown, FileText } from "lucide-react"
import { Icons } from "@/components/icons"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

export type TabType = 'inventory' | 'audit' | 'report' | 'active-no-sale' | 'discrepancies' | 'configuration'

interface SidebarProps {
    activeTab: TabType
    onTabChange: (tab: TabType) => void
    className?: string
    connectionName?: string
}

export function Sidebar({ activeTab, onTabChange, className, connectionName = "Master" }: SidebarProps) {
    const [isInventoryOpen, setIsInventoryOpen] = useState(true)

    const menuItems = [
        {
            id: 'inventory',
            label: 'Inventario por Tienda',
            icon: Icons.package,
        },
        {
            id: 'audit',
            label: 'Control de Inventario',
            icon: Icons.clipboard,
        },
        {
            id: 'report',
            label: 'Ventas sin Reg.',
            icon: Icons.chart,
        },
        {
            id: 'active-no-sale',
            label: 'Activo sin Venta',
            icon: Icons.alert,
        },
    ]

    return (
        <div className={cn("pb-12 min-h-screen border-r bg-card", className)}>
            <div className="space-y-4 py-4">
                <div className="px-3 py-2">
                    <div className="flex items-center gap-2 px-4 mb-2">
                        <Icons.package className="h-6 w-6 text-primary" />
                        <h2 className="text-lg font-bold tracking-tight">Inventario Tango</h2>
                    </div>
                    {/* Connection Status Badge */}
                    <div className="px-4 mb-4">
                        <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary/10 text-primary hover:bg-primary/20">
                            <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                            {connectionName}
                        </div>
                    </div>


                    <button
                        onClick={() => setIsInventoryOpen(!isInventoryOpen)}
                        className="w-full flex items-center justify-between mb-2 px-4 text-xs font-semibold tracking-tight text-muted-foreground uppercase hover:text-foreground transition-colors group"
                    >
                        <span>Inventario</span>
                        <ChevronDown className={cn("h-3 w-3 transition-transform", !isInventoryOpen && "-rotate-90")} />
                    </button>

                    {isInventoryOpen && (
                        <div className="space-y-1 animate-in slide-in-from-top-2 duration-200">
                            {menuItems.map((item) => (
                                <Button
                                    key={item.id}
                                    variant={activeTab === item.id ? "secondary" : "ghost"}
                                    className={cn(
                                        "w-full justify-start gap-3",
                                        activeTab === item.id && "bg-secondary font-bold text-primary"
                                    )}
                                    onClick={() => onTabChange(item.id as TabType)}
                                >
                                    <item.icon className="h-4 w-4" />
                                    {item.label}
                                </Button>
                            ))}
                        </div>
                    )}
                </div>

                <div className="px-3 py-2">
                    <h2 className="mb-2 px-4 text-xs font-semibold tracking-tight text-muted-foreground uppercase">
                        Conciliación
                    </h2>
                    <div className="space-y-1">
                        <Button
                            variant={activeTab === 'discrepancies' ? "secondary" : "ghost"}
                            className={cn(
                                "w-full justify-start gap-3",
                                activeTab === 'discrepancies' && "bg-secondary font-bold text-primary"
                            )}
                            onClick={() => onTabChange('discrepancies')}
                        >
                            <Icons.fileText className="h-4 w-4" />
                            Discrepancias
                        </Button>
                    </div>
                </div>

                <div className="px-3 py-2">
                    <h2 className="mb-2 px-4 text-xs font-semibold tracking-tight text-muted-foreground uppercase">
                        Sistema
                    </h2>
                    <div className="space-y-1">
                        <Button
                            variant={activeTab === 'configuration' ? "secondary" : "ghost"}
                            className={cn(
                                "w-full justify-start gap-3",
                                activeTab === 'configuration' && "bg-secondary font-bold text-primary"
                            )}
                            onClick={() => onTabChange('configuration')}
                        >
                            <Icons.sun className="h-4 w-4" />
                            Configuración
                        </Button>
                        <Button variant="ghost" className="w-full justify-start gap-3 text-destructive hover:text-destructive hover:bg-destructive/10">
                            <Icons.logout className="h-4 w-4" />
                            Cerrar Sesión
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}
