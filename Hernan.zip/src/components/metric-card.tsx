import { Card, CardContent } from "@/components/ui/card"
import { LucideIcon } from "lucide-react"

interface MetricCardProps {
    title: string
    value: string | number
    subtext?: string
    icon: LucideIcon
    trend?: {
        value: string
        isPositive: boolean
    }
}

export function MetricCard({ title, value, subtext, icon: Icon, trend }: MetricCardProps) {
    return (
        <Card>
            <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0 pb-2">
                    <p className="text-sm font-medium text-muted-foreground">{title}</p>
                    <Icon className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex flex-col gap-1">
                    <div className="text-2xl font-bold">{value}</div>
                    {subtext && (
                        <p className="text-xs text-muted-foreground">
                            {subtext}
                        </p>
                    )}
                    {trend && (
                        <p className={`text-xs flex items-center ${trend.isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
                            {trend.value}
                        </p>
                    )}
                </div>
            </CardContent>
        </Card>
    )
}
