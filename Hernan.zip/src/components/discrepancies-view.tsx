
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Loader2, Upload, FileSpreadsheet, Search, Download, Info } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

export function DiscrepanciesView() {
    // Original State
    const [file, setFile] = useState<File | null>(null);
    const [month, setMonth] = useState<string>('10');
    const [year, setYear] = useState<string>('2025');
    const [type, setType] = useState<string>('1');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Search State
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<any[]>([]);
    const [searchLoading, setSearchLoading] = useState(false);
    const [searchError, setSearchError] = useState<string | null>(null);

    const months = [
        { value: '1', label: 'Enero' },
        { value: '2', label: 'Febrero' },
        { value: '3', label: 'Marzo' },
        { value: '4', label: 'Abril' },
        { value: '5', label: 'Mayo' },
        { value: '6', label: 'Junio' },
        { value: '7', label: 'Julio' },
        { value: '8', label: 'Agosto' },
        { value: '9', label: 'Septiembre' },
        { value: '10', label: 'Octubre' },
        { value: '11', label: 'Noviembre' },
        { value: '12', label: 'Diciembre' },
    ];

    const reportTypes = [
        { value: '1', label: 'Discrepancia (Subsidios)' },
        { value: '2', label: 'Nuevas Activaciones' },
        { value: '3', label: 'Renovaciones' },
        { value: '4', label: 'Bonos Retención' },
        { value: '5', label: 'Prepago' },
    ];

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleProcess = async () => {
        if (!file) {
            setError('Por favor selecciona un archivo.');
            return;
        }

        setLoading(true);
        setError(null);

        const formData = new FormData();
        formData.append('file', file);
        formData.append('mes', month);
        formData.append('anio', year);
        formData.append('type', type);

        try {
            const response = await fetch('/api/discrepancies', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                throw new Error('Error al procesar el archivo');
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Reporte_${reportTypes.find(t => t.value === type)?.label.replace(/\s/g, '_')}_${year}_${month}.xlsx`;
            document.body.appendChild(a);
            a.click();
            a.remove();
        } catch (err) {
            setError('Ocurrió un error al procesar el reporte. Revisa la consola o intenta nuevamente.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = async () => {
        if (!searchQuery.trim()) return;
        setSearchLoading(true);
        setSearchError(null);
        setSearchResults([]);

        try {
            const res = await fetch(`/api/discrepancies/search?q=${encodeURIComponent(searchQuery)}`);
            if (!res.ok) throw new Error('Failed to fetch');
            const data = await res.json();
            setSearchResults(data);
        } catch (err) {
            console.error(err);
            setSearchError('Error al buscar. Intente nuevamente.');
        } finally {
            setSearchLoading(false);
        }
    };

    return (
        <div className="container mx-auto py-6 space-y-6">
            <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold tracking-tight">Conciliación</h2>
            </div>

            <Tabs defaultValue="upload" className="space-y-4">
                <TabsList>
                    <TabsTrigger value="upload" className="flex gap-2">
                        <Upload className="h-4 w-4" /> Carga de Reportes
                    </TabsTrigger>
                    <TabsTrigger value="download" className="flex gap-2">
                        <Download className="h-4 w-4" /> Descarga de Reportes
                    </TabsTrigger>
                    <TabsTrigger value="search" className="flex gap-2">
                        <Search className="h-4 w-4" /> Búsqueda
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="upload" className="space-y-4">
                    <Card className="border-none shadow-none md:border md:shadow-sm">
                        <CardHeader>
                            <CardTitle className="text-xl flex items-center gap-2">
                                <FileSpreadsheet className="h-5 w-5 text-blue-600" />
                                Procesar Archivo de Proveedor
                            </CardTitle>
                            <CardDescription>
                                Sube el archivo de importe del proveedor para generar el cruce de conciliación.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="month">Mes</Label>
                                    <Select value={month} onValueChange={setMonth}>
                                        <SelectTrigger id="month">
                                            <SelectValue placeholder="Selecciona mes" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {months.map((m) => (
                                                <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="year">Año</Label>
                                    <Input
                                        id="year"
                                        type="number"
                                        value={year}
                                        onChange={(e) => setYear(e.target.value)}
                                        min="2020"
                                        max="2030"
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="type">Tipo de Reporte</Label>
                                <Select value={type} onValueChange={setType}>
                                    <SelectTrigger id="type">
                                        <SelectValue placeholder="Selecciona tipo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {reportTypes.map((t) => (
                                            <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="file">Archivo de Importe (.xls / .xlsx)</Label>
                                <div className="flex items-center gap-4">
                                    <Input
                                        id="file"
                                        type="file"
                                        accept=".xls,.xlsx"
                                        onChange={handleFileChange}
                                        className="cursor-pointer"
                                    />
                                </div>
                                {file && <p className="text-sm text-muted-foreground mt-1">Archivo seleccionado: {file.name}</p>}
                            </div>

                            {error && (
                                <div className="p-3 bg-red-100 border border-red-200 text-red-700 rounded-md text-sm">
                                    {error}
                                </div>
                            )}

                            <Button
                                onClick={handleProcess}
                                disabled={loading || !file}
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                            >
                                {loading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Procesando...
                                    </>
                                ) : (
                                    <>
                                        <Upload className="mr-2 h-4 w-4" />
                                        Procesar y Descargar Reporte
                                    </>
                                )}
                            </Button>

                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="download">
                    <Card>
                        <CardHeader>
                            <CardTitle>Descarga de Reportes Generados</CardTitle>
                            <CardDescription>
                                Historial de reportes generados previamente.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="download-month">Mes</Label>
                                    <Select value={month} onValueChange={setMonth}>
                                        <SelectTrigger id="download-month">
                                            <SelectValue placeholder="Selecciona mes" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {months.map((m) => (
                                                <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="download-year">Año</Label>
                                    <Input
                                        id="download-year"
                                        type="number"
                                        value={year}
                                        onChange={(e) => setYear(e.target.value)}
                                        min="2020"
                                        max="2030"
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="download-type">Tipo de Reporte</Label>
                                <Select value={type} onValueChange={setType}>
                                    <SelectTrigger id="download-type">
                                        <SelectValue placeholder="Selecciona tipo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {reportTypes.map((t) => (
                                            <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <Button
                                onClick={async () => {
                                    setLoading(true);
                                    setError(null);
                                    try {
                                        const res = await fetch(`/api/discrepancies/download?mes=${month}&anio=${year}&type=${type}`);
                                        if (!res.ok) {
                                            const json = await res.json();
                                            throw new Error(json.error || 'Error al descargar reporte');
                                        }
                                        const blob = await res.blob();
                                        const url = window.URL.createObjectURL(blob);
                                        const a = document.createElement('a');
                                        a.href = url;
                                        a.download = `Reporte_${reportTypes.find(t => t.value === type)?.label.replace(/\s/g, '_')}_${year}_${month}.xlsx`;
                                        document.body.appendChild(a);
                                        a.click();
                                        a.remove();
                                        window.URL.revokeObjectURL(url);
                                    } catch (err: any) {
                                        setError(err.message);
                                    } finally {
                                        setLoading(false);
                                    }
                                }}
                                disabled={loading}
                                className="w-full"
                            >
                                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                                Descargar Histórico
                            </Button>

                            <div className="p-4 bg-muted/50 rounded-md text-sm text-muted-foreground">
                                <p className="flex items-center gap-2">
                                    <Info className="h-4 w-4" />
                                    Este reporte se genera en tiempo real consultando la base de datos de conciliaciones previas.
                                </p>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="search">
                    <Card>
                        <CardHeader>
                            <CardTitle>Búsqueda de Discrepancias</CardTitle>
                            <CardDescription>
                                Consulta reportes históricos por número de línea.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="flex gap-4">
                                <Input
                                    placeholder="Buscar por número de línea (ej. 7875551234)..."
                                    className="max-w-md"
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    // Trigger search on Enter
                                    onKeyDown={(e) => { if (e.key === 'Enter') handleSearch() }}
                                />
                                <Button onClick={handleSearch} disabled={searchLoading}>
                                    {searchLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                                    Buscar
                                </Button>
                            </div>

                            {searchError && (
                                <div className="p-3 bg-red-100 border border-red-200 text-red-700 rounded-md text-sm">
                                    {searchError}
                                </div>
                            )}

                            {searchResults.length > 0 ? (
                                <div className="max-h-[500px] overflow-auto border rounded-md">
                                    <Table>
                                        <TableHeader>
                                            <TableRow>
                                                <TableHead>Fecha</TableHead>
                                                <TableHead>Suscriptor</TableHead>
                                                <TableHead>Acción</TableHead>
                                                <TableHead>Importe</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                            {searchResults.map((row: any) => (
                                                <TableRow key={row.id}>
                                                    <TableCell>{row.anio}-{row.mesid}</TableCell>
                                                    <TableCell className="font-mono">{row.suscriber}</TableCell>
                                                    <TableCell>
                                                        <Badge variant="outline">{row.action}</Badge>
                                                    </TableCell>
                                                    <TableCell className="text-right">
                                                        {row.importe ? `$${row.importe}` : '-'}
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </div>
                            ) : (
                                !searchLoading && searchQuery && (
                                    <div className="mt-8 flex flex-col items-center justify-center p-8 text-muted-foreground opacity-50">
                                        <Search className="h-10 w-10 mb-2" />
                                        <p>No se encontraron resultados para "{searchQuery}".</p>
                                    </div>
                                )
                            )}

                            {!searchLoading && searchQuery === '' && (
                                <div className="mt-8 flex flex-col items-center justify-center p-8 text-muted-foreground opacity-50">
                                    <Search className="h-10 w-10 mb-2" />
                                    <p>Ingrese un número para comenzar la búsqueda.</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
