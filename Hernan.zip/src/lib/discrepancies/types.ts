export interface ReportData {
    emai: string;
    numero: string;
    fecha_activacion: string;
    ventatipoid: number;
    simcard?: string;
    comisionclaro: string;
    subsidio: string;
    bonoportabilidad: string;
    features: string;
    comisionpapper: string;
    discrepancia?: string;
    bono1?: string;
    bono2?: string;
    fecha?: string;
    numerocelularactivado: string; // Used in some contexts interchangeably with numero
}

export interface DiscrepancyResult {
    emai: string;
    subscriber: string;
    termino_contrato: string | null;
    itemid: string | null;
    priceplancod: string | null;
    priceplan: number | null;
    fechaactivacion: Date | null;
    fechaagente: Date | null;
    precioventaagente: number | null;
    precioventacliente: number | null;
}

export interface VentaTipo {
    nombre: string | null;
}

export interface DatosEmpresa {
    numeroagente: string | null;
    nombreagente: string | null;
    banagente: string | null;
}
