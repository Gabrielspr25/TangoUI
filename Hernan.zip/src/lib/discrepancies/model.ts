
import { PrismaClient } from '@prisma/client';
import { DiscrepancyResult, VentaTipo, DatosEmpresa, ReportData } from './types';

const prisma = new PrismaClient();

export class DiscrepancyModel {

    async close() {
        await prisma.$disconnect();
    }

    async prepagoSistema(mes: number, ano: number) {
        // Equivalent to: select a.* from venta as a inner join ventatipo as b on a.ventatipoid = b.ventatipoid  WHERE  (a.anio=".$ano." AND a.mesid=".$mes.")  AND b.ventacondicionid=2
        return await prisma.venta.findMany({
            where: {
                anio: BigInt(ano),
                mesid: BigInt(mes),
                ventatipo: {
                    ventacondicionid: BigInt(2)
                }
            },
            include: {
                ventatipo: true
            }
        });
    }

    async prepagoClaro(mes: number, ano: number) {
        // Equivalent to: select * from reporte_discrepancia as a WHERE  (a.anio=".$ano." AND a.mesid=".$mes.")  AND (a.action='Comisión Inicial 1' OR a.action='Comision Inicial BYOP' OR a.action='Prepago FWA' OR a.action='Comisión Prepago USF');
        return await prisma.reporte_discrepancia.findMany({
            where: {
                anio: BigInt(ano),
                mesid: BigInt(mes),
                action: {
                    in: ['Comisión Inicial 1', 'Comision Inicial BYOP', 'Prepago FWA', 'Comisión Prepago USF']
                }
            }
        });
    }

    calculateDate(mes: number, ano: number, posicion: number) {
        let con = 0;
        let mes_desde = 0;
        const mes_consulta = mes - posicion;

        for (let i = -11; i < 1; i++) {
            con += 1;
            if (mes_consulta === i) {
                mes_desde = con;
                const ano_desde = ano - 1;
                return { mes: mes_desde, ano: ano_desde };
            }
        }

        mes_desde = mes_consulta;
        const ano_desde = ano;
        return { mes: mes_desde, ano: ano_desde };
    }

    // consultinicial2_1
    async consultInitial2_1(anio: number, mes: number) {
        const date = this.calculateDate(mes, anio, 1);
        const mes_desde = date.mes;
        const ano_desde = date.ano;

        let mes_hasta: number;
        let ano_hasta: number;

        if (mes === 12) {
            mes_hasta = 1;
            ano_hasta = anio + 1;
        } else {
            mes_hasta = mes + 1;
            ano_hasta = anio;
        }

        // Logic translation:
        // Select from venta where ... 
        // AND EXISTS (select * from reporte_discrepancia where ... AND (action ='Comisión Inicial 2' OR action ='Comision Inicial Prepago 2 2'))

        return await prisma.venta.findMany({
            where: {
                anio: BigInt(ano_desde),
                mesid: BigInt(mes_desde),
                activo: true,
                ventatipo: {
                    ventacondicionid: BigInt(2)
                },
                numerocelularactivado: {
                    // This 'in' filter simulates the EXISTS clause by finding matching subscribers in reporte_discrepancia
                    in: (await prisma.reporte_discrepancia.findMany({
                        where: {
                            OR: [
                                { anio: BigInt(ano_desde), mesid: BigInt(mes_desde) },
                                { anio: BigInt(anio), mesid: BigInt(mes) },
                                { anio: BigInt(ano_hasta), mesid: BigInt(mes_hasta) }
                            ],
                            action: { in: ['Comisión Inicial 2', 'Comision Inicial Prepago 2 2'] }
                        },
                        select: { suscriber: true }
                    })).map(r => r.suscriber).filter((s): s is bigint => s !== null) // Ensure we filter out nulls
                }
            },
            include: {
                ventatipo: true
            }
        });
    }


    // consultinicial2_2
    async consultInitial2_2(anio: number, mes: number) {
        const date = this.calculateDate(mes, anio, 1);
        const mes_desde = date.mes;
        const ano_desde = date.ano;

        let mes_hasta: number;
        let ano_hasta: number;

        if (mes === 12) {
            mes_hasta = 1;
            ano_hasta = anio + 1;
        } else {
            mes_hasta = mes + 1;
            ano_hasta = anio;
        }

        // Logic translation:
        // Select from reporte_discrepancia where ...
        // AND EXISTS (select * from venta where ... )

        const ventasSubscribers = (await prisma.venta.findMany({
            where: {
                anio: BigInt(ano_desde),
                mesid: BigInt(mes_desde),
                activo: true,
                ventatipo: {
                    ventacondicionid: BigInt(2)
                }
            },
            select: { numerocelularactivado: true }
        })).map(v => v.numerocelularactivado).filter((s): s is bigint => s !== null);

        return await prisma.reporte_discrepancia.findMany({
            where: {
                OR: [
                    { anio: BigInt(ano_desde), mesid: BigInt(mes_desde) },
                    { anio: BigInt(anio), mesid: BigInt(mes) },
                    { anio: BigInt(ano_hasta), mesid: BigInt(mes_hasta) }
                ],
                action: { in: ['Comisión Inicial 2', 'Comision Inicial Prepago 2 2'] },
                suscriber: {
                    in: ventasSubscribers
                }
            }
        });
    }

    // consultinicial2_3
    async consultInitial2_3(anio: number, mes: number) {
        const date = this.calculateDate(mes, anio, 1);
        const mes_desde = date.mes;
        const ano_desde = date.ano;

        let mes_hasta: number;
        let ano_hasta: number;

        if (mes === 12) {
            mes_hasta = 1;
            ano_hasta = anio + 1;
        } else {
            mes_hasta = mes + 1;
            ano_hasta = anio;
        }

        // Logic translation:
        // Select from venta where ...
        // AND NOT EXISTS (select * from reporte_discrepancia ...)

        const reporteSubscribers = (await prisma.reporte_discrepancia.findMany({
            where: {
                OR: [
                    { anio: BigInt(ano_desde), mesid: BigInt(mes_desde) },
                    { anio: BigInt(anio), mesid: BigInt(mes) },
                    { anio: BigInt(ano_hasta), mesid: BigInt(mes_hasta) }
                ],
                action: { in: ['Comisión Inicial 2', 'Comision Inicial Prepago 2 2'] }
            },
            select: { suscriber: true }
        })).map(r => r.suscriber).filter((s): s is bigint => s !== null);

        return await prisma.venta.findMany({
            where: {
                anio: BigInt(ano_desde),
                mesid: BigInt(mes_desde),
                activo: true,
                ventatipo: {
                    ventacondicionid: BigInt(2)
                },
                numerocelularactivado: {
                    notIn: reporteSubscribers
                }
            },
            include: {
                ventatipo: true
            }
        });
    }

    // consult6month_1
    async consult6Month_1(anio: number, mes: number) {
        const date = this.calculateDate(mes, anio, 6);
        const mes_desde = date.mes;
        const ano_desde = date.ano;

        // Select from venta where ... AND EXISTS (reporte_discrepancia with 'Bono por Retención')

        const reporteSubscribers = (await prisma.reporte_discrepancia.findMany({
            where: {
                anio: BigInt(anio),
                mesid: BigInt(mes),
                action: 'Bono por Retención'
            },
            select: { suscriber: true }
        })).map(r => r.suscriber).filter((s): s is bigint => s !== null);

        return await prisma.venta.findMany({
            where: {
                anio: BigInt(ano_desde),
                mesid: BigInt(mes_desde),
                activo: true,
                bonoretencion: { gt: 0 },
                numerocelularactivado: {
                    in: reporteSubscribers
                }
            }
        });
    }

    // consult6month_2
    async consult6Month_2(anio: number, mes: number) {
        const date = this.calculateDate(mes, anio, 6);
        const mes_desde = date.mes;
        const ano_desde = date.ano;

        // Select from reporte_discrepancia where ... AND EXISTS (venta with bonoretencion > 0)

        const ventaSubscribers = (await prisma.venta.findMany({
            where: {
                anio: BigInt(ano_desde),
                mesid: BigInt(mes_desde),
                activo: true,
                bonoretencion: { gt: 0 }
            },
            select: { numerocelularactivado: true }
        })).map(v => v.numerocelularactivado).filter((s): s is bigint => s !== null);


        return await prisma.reporte_discrepancia.findMany({
            where: {
                anio: BigInt(anio),
                mesid: BigInt(mes),
                action: 'Bono por Retención',
                suscriber: {
                    in: ventaSubscribers
                }
            }
        });

    }

    // consult6month_3
    async consult6Month_3(anio: number, mes: number) {
        const date = this.calculateDate(mes, anio, 6);
        const mes_desde = date.mes;
        const ano_desde = date.ano;

        // Select from venta where ... AND NOT EXISTS

        const reporteSubscribers = (await prisma.reporte_discrepancia.findMany({
            where: {
                anio: BigInt(anio),
                mesid: BigInt(mes),
                action: 'Bono por Retención'
            },
            select: { suscriber: true }
        })).map(r => r.suscriber).filter((s): s is bigint => s !== null);

        return await prisma.venta.findMany({
            where: {
                anio: BigInt(ano_desde),
                mesid: BigInt(mes_desde),
                activo: true,
                bonoretencion: { gt: 0 },
                numerocelularactivado: {
                    notIn: reporteSubscribers
                }
            }
        });
    }

    // --- General Discrepancy logic (consult_1 to consult_4) ---
    // Note: The logic in PHP was slightly complex with OR conditions for months depending on if it's Jan or Dec.
    // I'll replicate the condition construction.

    getReporteOptions(anio: number, mes: number) {
        let options: { anio: bigint, mesid: bigint }[] = [];
        if (mes === 1) {
            options = [
                { anio: BigInt(anio), mesid: BigInt(mes) },
                { anio: BigInt(anio), mesid: BigInt(mes + 1) }
            ];
        } else if (mes === 12) {
            options = [
                { anio: BigInt(anio), mesid: BigInt(mes - 1) },
                { anio: BigInt(anio), mesid: BigInt(mes) }
            ];
        } else {
            options = [
                { anio: BigInt(anio), mesid: BigInt(mes - 1) },
                { anio: BigInt(anio), mesid: BigInt(mes) },
                { anio: BigInt(anio), mesid: BigInt(mes + 1) }
            ];
        }
        return options;
    }


    // consult_1: Registros en venta que NO aparecen en reporte de claro
    async consult_1(anio: number, mes: number) {
        // option1 is always current month/year for venta
        const ventaWhere = { anio: BigInt(anio), mesid: BigInt(mes) };

        // option2 is the range for reporte_discrepancia (prev, current, next month)
        const reporteOptions = this.getReporteOptions(anio, mes);

        const reporteSubscribers = (await prisma.reporte_discrepancia.findMany({
            where: {
                OR: reporteOptions
            },
            select: { suscriber: true }
        })).map(r => r.suscriber).filter((s): s is bigint => s !== null);

        return await prisma.venta.findMany({
            where: {
                ...ventaWhere,
                activo: true,
                numerocelularactivado: {
                    notIn: reporteSubscribers
                }
            }
        });
    }

    // consult_2: Registros en reporte_discrepancia que NO aparecen en venta
    async consult_2(anio: number, mes: number) {

        const reporteOptions = this.getReporteOptions(anio, mes);

        // Note: PHP logic reversed the complexity here. 
        // PHP: "Select * from reporte_discrepancia where " . $option1 . " and not exists (select * from venta where " . $option2 ...
        // In PHP:
        // if mes=1: option1 (reporte) matches broad range? No wait.
        // Let's look closely at PHP code:
        // consult_2:
        // option2="venta.anio=".$anio." and venta.mesid=".$mes;
        // option1="((anio=".$anio." and mesid=".$mes.") or (anio=".$anio." and mesid=".($mes+1)."))"; (if Jan)
        // Query: Select * from reporte_discrepancia where option1 (Range) AND NOT EXISTS (venta where option2 (Single))

        // So Reporte is queried with RANGE, and checked against Venta with SINGLE Month.

        const ventaWhere = { anio: BigInt(anio), mesid: BigInt(mes), activo: true };

        const ventasSubscribers = (await prisma.venta.findMany({
            where: ventaWhere,
            select: { numerocelularactivado: true }
        })).map(v => v.numerocelularactivado).filter((s): s is bigint => s !== null);

        return await prisma.reporte_discrepancia.findMany({
            where: {
                OR: reporteOptions,
                suscriber: {
                    notIn: ventasSubscribers
                }
            }
        });
    }

    // consult_3: Registros en venta que aparecen en reporte de claro (MATCH)
    async consult_3(anio: number, mes: number) {
        const ventaWhere = { anio: BigInt(anio), mesid: BigInt(mes) };
        const reporteOptions = this.getReporteOptions(anio, mes);

        const reporteSubscribers = (await prisma.reporte_discrepancia.findMany({
            where: { OR: reporteOptions },
            select: { suscriber: true }
        })).map(r => r.suscriber).filter((s): s is bigint => s !== null);

        return await prisma.venta.findMany({
            where: {
                ...ventaWhere,
                activo: true,
                numerocelularactivado: {
                    in: reporteSubscribers
                }
            }
        });
    }

    // consult_4: Registros en reporte que aparecen en venta (MATCH)
    async consult_4(anio: number, mes: number) {
        const reporteOptions = this.getReporteOptions(anio, mes);
        const ventaWhere = { anio: BigInt(anio), mesid: BigInt(mes), activo: true };

        const ventasSubscribers = (await prisma.venta.findMany({
            where: ventaWhere,
            select: { numerocelularactivado: true }
        })).map(v => v.numerocelularactivado).filter((s): s is bigint => s !== null);

        return await prisma.reporte_discrepancia.findMany({
            where: {
                OR: reporteOptions,
                suscriber: {
                    in: ventasSubscribers
                }
            }
        });
    }


    async ventaTipo(tipo: number): Promise<VentaTipo[]> {
        const result = await prisma.ventatipo.findUnique({
            where: { ventatipoid: BigInt(tipo) },
            include: {
                ventacondicion: true
            }
        });

        if (result && result.ventacondicion) {
            return [{ nombre: result.ventacondicion.nombre }];
        }
        return [];
    }

    async datosEmpresa(): Promise<DatosEmpresa[]> {
        const result = await prisma.datosempresa.findFirst();
        // Assuming single record or simplified return type for array compatibility
        if (result) {
            return [{
                numeroagente: result.numeroagente,
                nombreagente: result.nombreagente,
                banagente: result.banagente
            }];
        }
        return [];
    }

    async discrepancia(emai: string): Promise<DiscrepancyResult[]> {
        // Original SQL:
        // select a.emai,a.numerocelularactivado as subscriber,a.meses as termino_contrato,c.codigo as itemid,d.codigovoz as priceplancod,d.rate as priceplan,a.fechaactivacion,b.fechacompra as fechaagente,c.costo as precioventaagente,a.cobroequipoivu as precioventacliente 
        // from venta as a 
        // inner join inventario as b on a.emai=b.emai 
        // inner join equipo as c on b.equipoid=c.equipoid 
        // inner join tipoplan as d on a.codigovoz=d.codigovoz 
        // where a.emai='".$emai."'"

        // Note: This requires complex joining. Prisma `include` is often easier if relations are defined.
        // However, existing `schema.prisma` relations might not be perfect for this specific join path.
        // Also `venta.emai` is not a foreign key to `inventario.emai` in the schema shown previously (might be loose rel).
        // Let's verify relation. `venta` has no relation field to `inventario`. `inventario` has no relation to `venta`.
        // We must do separate queries or use raw query if performance critical. Since this is one-off by emai, separate queries is fine.

        // 1. Get Venta
        const venta = await prisma.venta.findFirst({
            where: { emai: emai },
            // include: { tipoplan: true } // Relation doesn't exist in Prisma schema
        });

        if (!venta) return [];

        // Fetch tipoplan separately if needed
        let tipoplan = null;
        if (venta.codigovoz) {
            tipoplan = await prisma.tipoplan.findFirst({
                where: { codigovoz: venta.codigovoz }
            });
        }


        // 2. Get Inventario
        const inventario = await prisma.inventario.findFirst({
            where: { emai: emai },
            include: { equipo: true }
        });

        if (!inventario || !inventario.equipo) return [];

        return [{
            emai: venta.emai || '',
            subscriber: venta.numerocelularactivado?.toString() || '',
            termino_contrato: venta.meses?.toString() || null,
            itemid: inventario.equipo.codigo || null,
            priceplancod: venta.codigovoz || null, // Assuming this is the link
            priceplan: tipoplan?.rate?.toNumber() || null,
            fechaactivacion: venta.fechaactivacion,
            fechaagente: inventario.fechacompra,
            precioventaagente: inventario.equipo.costo?.toNumber() || null,
            precioventacliente: venta.cobroequipoivu?.toNumber() || null
        }];
    }

    async getReportData(mes: number, anio: number, type: number): Promise<ReportData[]> {
        // Define action filters based on report type if known, or just fetch all for the month
        // Based on PHP/Legacy, specific reports filter specific actions.
        // Type 1: Discrepancies (Subsidios) -> likely all or specific subset?
        // Type 2: New Activations -> 'Nuevas' etc.

        // For now, let's fetch all records for the month/year and map them.
        // In a real scenario we'd precise the filtering.

        const results = await prisma.reporte_discrepancia.findMany({
            where: {
                anio: BigInt(anio),
                mesid: BigInt(mes)
            }
        });

        // Map to ReportData
        return results.map(r => {
            const val = r.commisionamount?.toNumber() || 0;
            // Heuristic: if Type 1 (Subsidio), use val as subsidio.
            // If Type 2 (Activations), use val as comisionclaro.
            // Ideally we'd distinguish by action but lacking strict mapping I'll populate both or contextually.

            const subsidioVal = (type === 1) ? val.toString() : "0";
            const comisionVal = (type === 2) ? val.toString() : "0";

            return {
                emai: r.imei || '',
                numero: r.suscriber?.toString() || '',
                fecha_activacion: r.activationdate ? r.activationdate.toISOString().split('T')[0] : '',
                ventatipoid: 1, // Default, since we don't have it. Processor might default to logic.
                simcard: r.simcard || '',
                comisionclaro: comisionVal,
                subsidio: subsidioVal,
                bonoportabilidad: '0',
                features: '0',
                comisionpapper: '0',
                numerocelularactivado: r.suscriber?.toString() || '',
                discrepancia: undefined
            };
        });
    }

    async search(query: string) {
        let whereClause: any = {};
        if (/^\d+$/.test(query)) {
            whereClause = { suscriber: BigInt(query) };
        } else {
            // Cannot search text in BigInt field properly
            return [];
        }

        return await prisma.reporte_discrepancia.findMany({
            where: whereClause,
            orderBy: { id: 'desc' },
            take: 50
        });
    }


}
