
import ExcelJS from 'exceljs';
import { DiscrepancyModel } from './model';
import { ReportData } from './types';

export class DiscrepancyProcessor {
    private model: DiscrepancyModel;

    constructor() {
        this.model = new DiscrepancyModel();
    }

    // Helper: Month name
    getMesNombre(mes: number) {
        const meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
        return meses[mes - 1] || "";
    }

    // Helper: Calculate Percentage logic from legacy
    porcentaje(precio: number): string {
        const porcentaje = (precio * 10.5) / 100;
        const number = precio + porcentaje;
        return number.toFixed(2);
    }

    async generateDiscrepancyReport(data: ReportData[], mes: number, anio: number): Promise<Buffer> {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Activaciones');

        // Styles
        const headerFill: ExcelJS.Fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: '3396FF' }
        };
        const headerFont = { color: { argb: 'FFFFFF' }, bold: true, size: 10 };

        // Header Info
        const datosEmpresa = await this.model.datosEmpresa();
        const empresa = datosEmpresa[0] || { nombreagente: '', numeroagente: '', banagente: '' };

        worksheet.getCell('A1').value = 'Agente:';
        worksheet.getCell('B1').value = empresa.nombreagente;
        worksheet.getCell('A2').value = 'Agent CODE:';
        worksheet.getCell('B2').value = empresa.numeroagente;
        worksheet.getCell('A3').value = 'BAN:';
        worksheet.getCell('B3').value = empresa.banagente;
        worksheet.getCell('A4').value = 'MES:';
        worksheet.getCell('B4').value = this.getMesNombre(mes);

        // Columns Header (Row 6)
        const headers = ['IMEI', 'SUBSCRIBER', 'TERMINO DE CONTRATO', 'ITEM ID', 'PRICE PLAN CODE', 'PRICE PLAN (COSTO)', 'FECHA ACTIVACION', 'FECHA DE VENTA AL AGENTE', 'PRECIO VENTA AGENTE', 'PRECIO VENTA CLIENTE', 'DIFERENCIA PRECIO/AJUSTE'];
        const headerRow = worksheet.getRow(6);
        headers.forEach((h, i) => {
            const cell = headerRow.getCell(i + 1);
            cell.value = h;
            cell.fill = headerFill;
            cell.font = headerFont;
        });

        let rowIdx = 7;
        for (const item of data) {
            if (item.subsidio !== "0") {
                const detalles = await this.model.discrepancia(item.emai);
                const detalle = detalles[0] || {};

                const row = worksheet.getRow(rowIdx);
                row.getCell(1).value = " " + item.emai;
                row.getCell(2).value = item.numero;
                row.getCell(3).value = detalle.termino_contrato;
                row.getCell(4).value = detalle.itemid;
                row.getCell(5).value = detalle.priceplancod;
                row.getCell(6).value = detalle.priceplan;
                row.getCell(7).value = item.fecha_activacion;
                row.getCell(8).value = detalle.fechaagente?.toISOString().split('T')[0];
                row.getCell(9).value = this.porcentaje(detalle.precioventaagente || 0); // Logic from legacy
                row.getCell(10).value = detalle.precioventacliente;
                row.getCell(11).value = item.subsidio;

                rowIdx++;
            }
        }

        // Autosize columns (approximate)
        worksheet.columns.forEach(column => {
            column.width = 20;
        });

        const buffer = await workbook.xlsx.writeBuffer();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return buffer as any;
    }

    // Implements "option1" - Nuevas
    async generateNewActivationsReport(data: ReportData[], mes: number, anio: number): Promise<Buffer> {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Activaciones');

        // Styles
        const headerFill: ExcelJS.Fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '3396FF' } };
        const headerFont = { color: { argb: 'FFFFFF' }, bold: true, size: 10 };

        // Header Info
        const datosEmpresa = await this.model.datosEmpresa();
        const empresa = datosEmpresa[0] || { nombreagente: '', numeroagente: '', banagente: '' };

        worksheet.getCell('A1').value = 'Agente:';
        worksheet.getCell('B1').value = empresa.nombreagente;
        worksheet.getCell('A2').value = 'Agent CODE:';
        worksheet.getCell('B2').value = empresa.numeroagente;
        worksheet.getCell('A3').value = 'BAN:';
        worksheet.getCell('B3').value = empresa.banagente;
        worksheet.getCell('A4').value = 'MES:';
        worksheet.getCell('B4').value = this.getMesNombre(mes);

        const headers = ['CodAsociado', 'CodigoSucursal', 'Telefono', 'FechaActivacion', 'ProductCode', 'NumeroOrden', 'SIM CARD', 'Comision', 'Comision Contestada', 'Portabilidad', 'Portabilidad Contestada', 'Paperless', 'Paperless Contestada', 'Seguro', 'Seguro Contestada', 'Total Discrepado', 'Total Contestado', 'Nota'];
        const headerRow = worksheet.getRow(6);
        headers.forEach((h, i) => {
            const cell = headerRow.getCell(i + 1);
            cell.value = h;
            cell.fill = headerFill;
            cell.font = headerFont;
        });

        let rowIdx = 7;
        for (const item of data) {
            const tipos = await this.model.ventaTipo(item.ventatipoid);
            if (tipos.length > 0 && tipos[0].nombre === "Contrato") {
                const row = worksheet.getRow(rowIdx);
                row.getCell(1).value = empresa.numeroagente;
                row.getCell(2).value = "";
                row.getCell(3).value = item.numero;
                row.getCell(4).value = item.fecha_activacion;
                // ... map other fields based on legacy mapping
                row.getCell(7).value = (item.simcard !== "null") ? item.simcard : "";
                row.getCell(8).value = (item.comisionclaro !== "NaN") ? item.comisionclaro : "0";
                row.getCell(10).value = (item.bonoportabilidad !== "NaN") ? item.bonoportabilidad : "0";
                row.getCell(12).value = (item.comisionpapper !== "NaN") ? item.comisionpapper : "0";
                row.getCell(14).value = (item.features !== "NaN") ? item.features : "0";
                row.getCell(16).value = item.discrepancia;

                rowIdx++;
            }
        }

        worksheet.columns.forEach(c => c.width = 15);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return await workbook.xlsx.writeBuffer() as any;
    }
}
