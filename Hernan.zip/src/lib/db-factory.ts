import { PrismaClient } from '@prisma/client';
import { cookies } from 'next/headers';
import prisma from './prisma'; // Default "Master" client

// Cache for PrismaClient instances to prevent exhaustion
const clients = new Map<string, PrismaClient>();

export async function getPrismaClient() {
    const cookieStore = await cookies();
    const clientId = cookieStore.get('active_client')?.value;

    // If no client selected or "master", return default
    if (!clientId || clientId === 'master') {
        return prisma;
    }

    // Return cached client if exists
    if (clients.has(clientId)) {
        return clients.get(clientId)!;
    }

    try {
        // Fetch connection details from Master DB
        // We use BigInt for ID, so we need to handle that if clientId is string
        // Assuming clientId stored in cookie is the string representation of BigInt ID
        const clientConfig = await prisma.bbddclientes.findFirst({
            where: {
                bbddclientesid: BigInt(clientId),
            },
        });

        if (!clientConfig) {
            console.warn(`[db-factory] Client ID ${clientId} not found in bbddclientes. Falling back to Master.`);
            return prisma;
        }

        // Construct connection string for Postgres
        // Format: postgresql://USER:PASSWORD@HOST:PORT/DATABASE?schema=public
        // FORCE USER 'postgres' because 'nombre' is a company name with spaces
        // FORCE PORT 5432 because 'puerto' is often wrong (8080)
        const connectionString = `postgresql://postgres:${clientConfig.password}@${clientConfig.ip}:5432/${clientConfig.nombrebase}?schema=public`;

        console.log(`[db-factory] Connecting to client ${clientId} (${clientConfig.nombrebase}) at ${clientConfig.ip}:5432 as postgres...`);

        // Create new client instance
        const newClient = new PrismaClient({
            datasources: {
                db: {
                    url: connectionString,
                },
            },
        });

        // Test connection (optional, but good for debug)
        // await newClient.$connect(); 

        // Cache it
        clients.set(clientId, newClient);

        return newClient;
    } catch (error) {
        console.error('[db-factory] Error creating dynamic client:', error);
        return prisma; // Fallback to master on error
    }
}

// Helper to get current client info for UI
export async function getCurrentClientInfo() {
    const cookieStore = await cookies();
    const clientId = cookieStore.get('active_client')?.value;

    if (!clientId || clientId === 'master') {
        return { name: 'Master', id: 'master' };
    }

    try {
        const clientConfig = await prisma.bbddclientes.findFirst({
            where: {
                bbddclientesid: BigInt(clientId),
            },
        });

        return {
            name: clientConfig?.nombre || 'Unknown',
            id: clientId
        };
    } catch (e) {
        return { name: 'Error', id: 'master' };
    }
}
