const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function main() {
    try {
        console.log("--- ACTIVADO = TRUE (Expected: In Stock) ---");
        const trueItems = await prisma.inventario.findMany({
            where: { activado: true, generico: false },
            take: 3,
            select: { inventarioid: true, activado: true, fechacompra: true, emai: true, equipo: { select: { nombre: true } } }
        });
        console.log(JSON.stringify(trueItems, (key, value) =>
            typeof value === 'bigint' ? value.toString() : value // Handle BigInt
            , 2));

        console.log("\n--- ACTIVADO = FALSE (Expected: Sold/Inactive) ---");
        const falseItems = await prisma.inventario.findMany({
            where: { activado: false, generico: false },
            take: 3,
            select: { inventarioid: true, activado: true, fechacompra: true, emai: true, equipo: { select: { nombre: true } } }
        });
        console.log(JSON.stringify(falseItems, (key, value) =>
            typeof value === 'bigint' ? value.toString() : value // Handle BigInt
            , 2));
    } catch (e) {
        console.error(e);
    } finally {
        await prisma.$disconnect();
    }
}

main();
