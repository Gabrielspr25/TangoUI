
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    const inventarioId = BigInt(39820);
    const ventaId = BigInt(78892);

    console.log("--- Inspecting Known Item ---");

    const inv = await prisma.inventario.findUnique({
        where: { inventarioid: inventarioId }
    });
    console.log("Inventario Record:", inv);

    const venta = await prisma.venta.findUnique({
        where: { ventaid: ventaId }
    });
    console.log("Venta Record:", venta);

    if (inv && venta) {
        console.log("\n--- Comparison ---");
        console.log(`Venta.emai: ${venta.emai}`);
        console.log(`Venta.simcard: ${venta.simcard}`);
        console.log(`Inventario.emai: ${inv.emai}`);
        console.log(`Match V.emai == I.emai? ${venta.emai === inv.emai}`);
        console.log(`Match V.simcard == I.emai? ${venta.simcard === inv.emai}`);
    }
}

main()
    .catch(e => console.error(e))
    .finally(async () => await prisma.$disconnect());
